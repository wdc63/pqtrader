# qtrader/core/scheduler.py

import time as time_module
from datetime import datetime, time, timedelta, date
from typing import List
from qtrader.core.context import Context
from qtrader.core.time_manager import TimeManager
from qtrader.core.lifecycle import LifecycleManager
from qtrader.trading.matching_engine import MatchingEngine

class Scheduler:
    """
    事件调度器 (V6 - 带有市场阶段管理和响应式自愈)
    
    角色定位：响应器 (The Responder) & 状态机
    - 状态机：管理实时循环中的市场阶段和每日事件标志。
    - 响应器：响应“时间同步”请求，命令 Engine 进行自愈。
    """

    def __init__(
        self,
        context: Context,
        time_manager: TimeManager,
        matching_engine: MatchingEngine,
        lifecycle_manager: LifecycleManager
    ):
        self.context = context
        self.time_manager = time_manager
        self.matching_engine = matching_engine
        self.lifecycle_manager = lifecycle_manager
        
        self.config = context.config
        self.engine_config = self.config.get('engine', {})
        self.lifecycle_config = self.config.get('lifecycle', {})
        self.server_config = self.config.get('server', {})
        self._server_enabled = self.server_config.get('enable', False)
        self._update_interval = self.server_config.get('update_interval', 1.0)
        self._enable_intraday_statistics = self.engine_config.get('enable_intraday_statistics', False)
        self._intraday_update_freq = self.engine_config.get('intraday_update_frequency', 5)
        self._intraday_last_record_minute = -1
        self._benchmark_start_of_day_price = None
        self._strategy_start_of_day_value = None
        self._schedule_points = self._build_schedule_points()

    def _enter_pause_loop(self) -> bool:
        """进入暂停等待循环"""
        while self.context.is_paused:
            if self.context.stop_requested:
                self.context.logger.info("在暂停期间收到停止指令，即将退出。")
                self.context.is_running = False
                self.context.was_interrupted = True
                return False
            time_module.sleep(0.1)
        return self.context.is_running

    def _check_and_handle_requests(self) -> bool:
        """检查暂停/停止请求"""
        if self.context.stop_requested:
            self.context.logger.info("响应停止请求，即将终止回测循环。")
            self.context.is_running = False
            self.context.was_interrupted = True
            return False

        if self.context.pause_requested:
            self.context.logger.info(f"响应暂停请求，将在 {self.context.current_dt} 暂停。")
            
            if self._enable_intraday_statistics:
                self._update_intraday_statistics(self.context.current_dt, force_update=True)
            
            if self.context.state_serializer:
                self.context.state_serializer.save(tag='pause')

            self.context.is_paused = True
            self.context.pause_requested = False

            self._maybe_update_server()

            while self.context.is_paused:
                if self.context.stop_requested:
                    self.context.logger.info("在暂停期间收到停止指令，即将退出。")
                    self.context.is_running = False
                    self.context.was_interrupted = True
                    return False
                time_module.sleep(0.1)
            
            if not self.context.is_running:
                return False
        
        return True

    def run(self, skip_initialize: bool = False):
        """
        [MODIFIED] 主运行循环，增加了“启动即暂停”的处理逻辑。
        """
        if not skip_initialize:
            self.lifecycle_manager.call_initialize()
            if self.context.mode == 'simulation' and self.context.resync_requested:
                self.context.engine._synchronize_to_realtime(); self.context.resync_requested = False

        if self.context.start_paused:
            self.context.logger.info("运行以暂停状态启动。请在监控页面点击 '恢复' 继续。")
            self.context.is_paused = True
            self.context.start_paused = False
            self._maybe_update_server()
            if not self._enter_pause_loop():
                return

        if self.context.mode == 'backtest':
            self._run_backtest(skip_initialize)
        else:
            self._run_simulation()

    def _run_backtest(self, skip_initialize: bool = False):
        """回测模式运行循环"""
        start_date_str = self.context.start_date
        end_date_str = self.context.end_date
        resume_dt = self.context.current_dt if skip_initialize else None

        if resume_dt:
            start_date_str = resume_dt.strftime('%Y-%m-%d')
            self.context.logger.info(f"从 {start_date_str} 的 {resume_dt.strftime('%H:%M:%S')} 之后继续回测")

        trading_days = self.time_manager.get_trading_days(start_date_str, end_date_str)
        
        if not trading_days:
            self.context.logger.warning("在指定日期范围内没有交易日，回测结束。")
            self.lifecycle_manager.call_on_end()
            return

        total_days = len(trading_days)
        self.context.logger.info(f"回测开始，共 {total_days} 个交易日")

        hooks = self.lifecycle_config.get('hooks', {})
        before_trading_time = hooks.get('before_trading', '09:15:00')
        after_trading_time = hooks.get('after_trading', '15:05:00')
        broker_settle_time = hooks.get('broker_settle', '15:30:00')

        for idx, date_str in enumerate(trading_days):
            if not self.context.is_running:
                self.context.logger.info("回测被手动停止")
                break

            self.context.logger.info(f"--- 交易日: {date_str} ({idx + 1}/{total_days}) ---")

            points_to_iterate = self._schedule_points
            is_resume_day = (resume_dt is not None and date_str == resume_dt.strftime('%Y-%m-%d'))

            if is_resume_day:
                self.context.logger.info("此为恢复日，跳过盘前准备流程。")
                if self.context.portfolio.history: self._strategy_start_of_day_value = self.context.portfolio.history[-1]['total_value']
                if self.context.benchmark_manager.benchmark_history: self._benchmark_start_of_day_price = self.context.benchmark_manager.benchmark_history[-1].get('close_price')
                self._intraday_last_record_minute = resume_dt.minute if resume_dt else -1

                try:
                    resume_time_str = resume_dt.strftime('%H:%M:%S')
                    points_to_iterate = [time_str for time_str in self._schedule_points if time_str > resume_time_str]
                    
                    if points_to_iterate: self.context.logger.info(f"根据新的调度计划，将从 bar: {points_to_iterate[0]} 开始执行。")
                    else:
                        self.context.logger.info(f"恢复时间 ({resume_time_str}) 已晚于新调度计划中的所有时间点，直接进入盘后流程。")
                        points_to_iterate = []
                except ValueError:
                    self.context.logger.warning(f"无法在执行计划中找到恢复时间点 {resume_time_str}，将执行当天所有 bar。")
            else:
                self._intraday_last_record_minute = -1
                self.context.symbol_info_cache.clear()
                self.context.intraday_equity_history.clear()
                self.context.intraday_benchmark_history.clear()
                self._benchmark_start_of_day_price = None
                self._strategy_start_of_day_value = None

                dt_before_trading = datetime.strptime(f"{date_str} {before_trading_time}", "%Y-%m-%d %H:%M:%S")
                self.context.current_dt = dt_before_trading
                self.lifecycle_manager.call_before_trading()

                if self.context.portfolio.history: self._strategy_start_of_day_value = self.context.portfolio.history[-1]['total_value']
                if self.context.benchmark_manager.benchmark_history: self._benchmark_start_of_day_price = self.context.benchmark_manager.benchmark_history[-1].get('close_price')
                
                self._maybe_update_server()
                if not self._check_and_handle_requests(): break

            for time_str in points_to_iterate:
                dt_bar = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S")
                self.context.current_dt = dt_bar
                self.lifecycle_manager.call_handle_bar()
                self.matching_engine.match_orders(dt_bar)

                if self._enable_intraday_statistics: self._update_intraday_statistics(dt_bar)
                self._maybe_update_server()

                if not self._check_and_handle_requests(): break
            
            if not self.context.is_running: break

            dt_after_trading = datetime.strptime(f"{date_str} {after_trading_time}", "%Y-%m-%d %H:%M:%S")
            self.context.current_dt = dt_after_trading
            self.lifecycle_manager.call_after_trading()
            self._maybe_update_server()
            if not self._check_and_handle_requests(): break

            dt_settle = datetime.strptime(f"{date_str} {broker_settle_time}", "%Y-%m-%d %H:%M:%S")
            self.context.current_dt = dt_settle
            self.matching_engine.settle()
            self.lifecycle_manager.call_broker_settle()
            self.context.benchmark_manager.update_daily()
            self._maybe_update_server()
            if not self._check_and_handle_requests(): break
            
            if self.context.config.get('workspace', {}).get('auto_save_state', False):
                auto_save_interval = self.context.config.get('workspace', {}).get('auto_save_interval', 10)
                auto_save_mode = self.context.config.get('workspace', {}).get('auto_save_mode', 'increment')
                if (idx + 1) % auto_save_interval == 0:
                    if self.context.state_serializer:
                        tag = 'auto_save' if auto_save_mode == 'overwrite' else f'auto_save_day_{idx+1}'
                        self.context.state_serializer.save(tag=tag)

        self.lifecycle_manager.call_on_end()
        self.context.logger.info("回测结束")

    def _check_for_resync(self, state_machine):
        """
        [NEW] 检查并执行时间同步的核心逻辑。这是 Scheduler 作为“响应器”的关键。
        """
        if self.context.resync_requested:
            self.context.logger.info("响应同步请求，正在命令引擎重新校准时间...")
            self.context.engine._synchronize_to_realtime()
            state_machine['daily_flags'] = { k: False for k in state_machine['daily_flags'] }
            state_machine['last_handle_bar_dt'] = self.context.current_dt
            state_machine['last_known_date'] = self.context.current_dt.date()
            self.context.resync_requested = False
            return True, state_machine
        return False, state_machine

    def _run_simulation(self):
        """[MODIFIED] 模拟盘实时循环，增加市场阶段管理和响应式自愈"""
        self.context.logger.info("模拟盘模式启动，基于真实时间运行...")
        
        state_machine = {
            'daily_flags': {'before_trading_done': False, 'after_trading_done': False, 'settle_done': False},
            'last_known_date': self.context.current_dt.date() if self.context.current_dt else date(1970, 1, 1),
            'schedule_today': self._build_schedule_points(),
            'next_schedule_idx': 0
        }
        
        hooks = self.lifecycle_config.get('hooks', {}); before_trading_time = datetime.strptime(hooks.get('before_trading', '09:15:00'), '%H:%M:%S').time(); after_trading_time = datetime.strptime(hooks.get('after_trading', '15:05:00'), '%H:%M:%S').time(); broker_settle_time = datetime.strptime(hooks.get('broker_settle', '15:30:00'), '%H:%M:%S').time();
        sessions = self.lifecycle_config.get('trading_sessions', []); trading_sessions = [(datetime.strptime(s, '%H:%M:%S').time(), datetime.strptime(e, '%H:%M:%S').time()) for s, e in sessions]

        while self.context.is_running:
            now = datetime.now()
            self.context.current_dt = now # [FIX] Update context time at the very beginning of the loop.
            
            if now.date() > state_machine['last_known_date']:
                self.context.logger.info(f"--- 新交易日: {now.strftime('%Y-%m-%d')} ---")
                state_machine['daily_flags'] = {'before_trading_done': False, 'after_trading_done': False, 'settle_done': False}
                state_machine['last_known_date'] = now.date()
                state_machine['schedule_today'] = self._build_schedule_points()
                state_machine['next_schedule_idx'] = 0
                self.context.strategy_error_today = False
                self.context.order_manager.clear_today_orders()
                self.context.intraday_equity_history.clear()
                self.context.intraday_benchmark_history.clear()

                # [FIX] 为新交易日设置日内统计的基准值
                if self.context.portfolio.history:
                    self._strategy_start_of_day_value = self.context.portfolio.history[-1]['total_value']
                    self.context.logger.debug(f"设置日内策略基准价值: {self._strategy_start_of_day_value}")
                if self.context.benchmark_manager.benchmark_history:
                    self._benchmark_start_of_day_price = self.context.benchmark_manager.benchmark_history[-1].get('close_price')
                    self.context.logger.debug(f"设置日内基准价格: {self._benchmark_start_of_day_price}")

            is_trading_day = self.time_manager.is_trading_day(now)

            if is_trading_day:
                current_time = now.time()
                # [REFACTOR] More robust market phase state machine to prevent trading after market close.
                if any(start <= current_time <= end for start, end in trading_sessions):
                    self.context.market_phase = 'TRADING'
                elif before_trading_time <= current_time < trading_sessions[0][0]:
                    self.context.market_phase = 'BEFORE_TRADING'
                elif trading_sessions[-1][1] < current_time < broker_settle_time:
                    self.context.market_phase = 'AFTER_TRADING'
                elif current_time >= broker_settle_time:
                    self.context.market_phase = 'SETTLEMENT'
                else:
                    # Covers pre-market, lunch break, and other non-trading times on a trading day.
                    self.context.market_phase = 'CLOSED'

                if self.context.market_phase == 'BEFORE_TRADING' and not state_machine['daily_flags'].get('before_trading_done'):
                    self.lifecycle_manager.call_before_trading(); synced, state_machine = self._check_for_resync(state_machine)
                    if synced: continue
                    state_machine['daily_flags']['before_trading_done'] = True; self._maybe_update_server()

                if self.context.market_phase == 'TRADING':
                    # [REFACTOR] Schedule-driven event loop for multi-frequency support
                    idx = state_machine.get('next_schedule_idx', 0)
                    schedule = state_machine.get('schedule_today', [])
                    current_time = now.time()
                    synced = False

                    # Catch up on any missed handle_bar events for today
                    while idx < len(schedule):
                        next_event_time_str = schedule[idx]
                        next_event_time = datetime.strptime(next_event_time_str, '%H:%M:%S').time()

                        if current_time >= next_event_time:
                            event_dt = datetime.combine(now.date(), next_event_time)
                            self.context.current_dt = event_dt

                            self.lifecycle_manager.call_handle_bar()
                            synced, state_machine = self._check_for_resync(state_machine)
                            if synced: break

                            self.matching_engine.match_orders(event_dt)
                            idx += 1
                            state_machine['next_schedule_idx'] = idx
                            self._maybe_update_server()
                        else:
                            break # Not time for the next event yet
                    
                    if synced: continue

                    # Intraday statistics are checked independently after handling events
                    if self._enable_intraday_statistics:
                        if self._update_intraday_statistics(now):
                            self._maybe_update_server()
                
                if self.context.market_phase == 'AFTER_TRADING' and not state_machine['daily_flags'].get('after_trading_done'):
                    self.lifecycle_manager.call_after_trading(); synced, state_machine = self._check_for_resync(state_machine)
                    if synced: continue
                    state_machine['daily_flags']['after_trading_done'] = True
                    self._maybe_update_server() # [FIX] Trigger server update after after_trading hook
                
                if self.context.market_phase == 'SETTLEMENT' and not state_machine['daily_flags'].get('settle_done'):
                    self.matching_engine.settle(); self.lifecycle_manager.call_broker_settle(); synced, state_machine = self._check_for_resync(state_machine)
                    if synced: continue
                    self.context.benchmark_manager.update_daily(); state_machine['daily_flags']['settle_done'] = True
                    self._maybe_update_server() # [FIX] Trigger server update after settlement
            else:
                self.context.market_phase = 'CLOSED'

            if not self._check_and_handle_requests(): break
            time_module.sleep(1)

        self.lifecycle_manager.call_on_end()
        self.context.logger.info("模拟盘运行结束")

    def _maybe_update_server(self):
        """如果服务器启用，更新数据（性能优先：异步、有间隔）"""
        if self._server_enabled and self.context.visualization_server:
            self.context.visualization_server.trigger_update()

    def _build_schedule_points(self) -> List[str]:
        """构建盘中时间点列表"""
        freq = self.context.frequency
        
        if freq == 'daily':
            hooks = self.lifecycle_config.get('hooks', {})
            handle_bar_time = hooks.get('handle_bar', '14:55:00')
            return [handle_bar_time] if isinstance(handle_bar_time, str) else handle_bar_time

        schedule = []
        sessions = self.lifecycle_config.get('trading_sessions', [])

        for start_str, end_str in sessions:
            current_dt = datetime.strptime(start_str, '%H:%M:%S')
            end_dt = datetime.strptime(end_str, '%H:%M:%S')
            tick_interval_seconds = self.engine_config.get('tick_interval_seconds', 3)
            delta = timedelta(minutes=1) if freq == 'minute' else timedelta(seconds=tick_interval_seconds)

            while current_dt <= end_dt:
                schedule.append(current_dt.strftime('%H:%M:%S'))
                current_dt += delta

        return sorted(list(set(schedule)))
    
    def _update_intraday_statistics(self, dt: datetime, force_update: bool = False) -> bool:
        """
        [MODIFIED] 按指定频率记录账户与基准的日内价值, 并返回是否进行了更新。
        """
        current_minute = dt.minute

        is_on_schedule = (dt.minute % self._intraday_update_freq == 0 and current_minute != self._intraday_last_record_minute)
        if not force_update and not is_on_schedule:
            return False

        self._intraday_last_record_minute = current_minute
        
        pm = self.context.position_manager
        position_value = 0.0
        for pos in pm.get_all_positions():
            price_data = self.context.data_provider.get_current_price(pos.symbol, dt)
            current_price = price_data['current_price'] if price_data else pos.current_price
            pos.update_price(current_price)
            position_value += pos.market_value
        
        total_value = self.context.portfolio.cash + position_value
        
        self.context.intraday_equity_history.append({
            'time': dt.strftime('%H:%M:%S'),
            'total_value': total_value,
        })
        
        benchmark_symbol = self.context.benchmark_manager.benchmark_symbol
        if benchmark_symbol and self._benchmark_start_of_day_price and self._strategy_start_of_day_value:
            price_data = self.context.data_provider.get_current_price(benchmark_symbol, dt)
            if price_data and price_data.get('current_price'):
                current_benchmark_price = price_data['current_price']
                if self._benchmark_start_of_day_price > 0:
                    current_benchmark_value = self._strategy_start_of_day_value * (current_benchmark_price / self._benchmark_start_of_day_price)
                    self.context.intraday_benchmark_history.append({
                        'time': dt.strftime('%H:%M:%S'),
                        'value': current_benchmark_value,
                    })
        return True