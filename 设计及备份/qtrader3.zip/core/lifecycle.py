# qtrader/core/lifecycle.py

from typing import Optional
import time
import traceback # 引入 traceback 模块以打印详细的错误信息
from qtrader.core.context import Context
from qtrader.strategy.base import Strategy

class LifecycleManager:
    """
    生命周期管理器 (V6 - 带有异常隔离防火墙和阻塞看门狗)
    
    角色定位：检测器 (The Detector) & 安全执行器
    - 安全执行器：确保用户代码的异常不会搞垮整个框架。
    - 检测器：监控用户代码的执行耗时，并在超时后发出警报。
    """

    def __init__(self, context: Context):
        self.context = context
        self.strategy: Optional[Strategy] = None
        # [NEW] 从配置中读取阻塞阈值。
        self.block_threshold_seconds = self.context.config.get('engine', {}).get('block_threshold_seconds', 5)

    def register_strategy(self, strategy: Strategy):
        self.strategy = strategy

    def _call_hook(self, hook_name: str):
        """
        [MODIFIED] 通用钩子调用函数，内置两大核心安全机制。
        这是整个健壮性设计的关键所在。
        """
        if self.strategy is None:
            self.context.logger.error("错误: 策略对象未注册。")
            return

        hook_method = getattr(self.strategy, hook_name, None)
        if callable(hook_method):
            
            is_simulation = self.context.mode == 'simulation'
            time_before = time.monotonic() if is_simulation else 0
            
            # --- 机制一: 异常隔离防火墙 ---
            try:
                self.context.logger.debug(f"调用策略钩子: {hook_name}()")
                hook_method(self.context)
            
            # 捕获所有源自用户代码的异常
            except Exception as e:
                # [MODIFIED] 不再停止引擎！这是保证框架鲁棒性的关键。
                
                # 记录详细的错误日志，包括完整的 traceback，方便用户定位问题。
                error_trace = traceback.format_exc()
                self.context.logger.error(f"执行策略钩子 {hook_name}() 时发生严重错误: {e}")
                self.context.logger.error(f"详细错误追踪:\n{error_trace}")
                
                # [NEW] 设置当日错误标志，用于UI告警。
                self.context.strategy_error_today = True
                
                # 即使发生错误，也让框架继续运行。
                return

            # --- 机制二: 阻塞看门狗 ---
            if is_simulation:
                time_after = time.monotonic()
                duration = time_after - time_before
                
                # 如果执行时间超过了我们设定的阈值
                if duration > self.block_threshold_seconds:
                    self.context.logger.warning(f"检测到策略钩子 '{hook_name}' 严重阻塞 {duration:.2f} 秒！")
                    self.context.logger.warning("已触发时间同步请求，系统将自动校准...")
                    
                    # [NEW] 举起“信号旗”，通知 Scheduler 需要进行时间同步。
                    self.context.resync_requested = True
    
    # 其他 call_... 方法保持不变，它们自动继承了 _call_hook 的安全特性
    def call_initialize(self):
        self._call_hook('initialize')

    def call_before_trading(self):
        self._call_hook('before_trading')

    def call_handle_bar(self):
        self._call_hook('handle_bar')

    def call_after_trading(self):
        self._call_hook('after_trading')

    def call_broker_settle(self):
        self._call_hook('broker_settle')

    def call_on_end(self):
        self._call_hook('on_end')
