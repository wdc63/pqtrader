# qtrader/core/context.py

from datetime import datetime
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
import logging

# 避免循环导入的类型提示
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..trading.account import Portfolio
    from ..trading.order_manager import OrderManager
    from ..trading.position_manager import PositionManager
    from ..benchmark.benchmark_manager import BenchmarkManager
    from ..analysis.integrated_server import IntegratedServer
    from ..data.interface import AbstractDataProvider
    from .engine import Engine

@dataclass
class Context:
    """
    全局上下文对象 (V6)
    这是框架中最核心的对象，是所有组件共享信息和状态的“中央总线”。
    """

    # ========== 基础运行信息 ==========
    mode: str = 'backtest'
    strategy_name: str = 'UnnamedStrategy'
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    current_dt: Optional[datetime] = None
    
    # [NEW] 市场阶段状态，由 Scheduler 负责更新。
    # 为什么？这是“赋能用户”的关键。它为策略代码提供了一个清晰、可靠的判断依据，
    # 知道当前真实的市场阶段，从而可以编写出能应对盘中启动等异常情况的健壮逻辑。
    market_phase: str = 'CLOSED' # 可能的值: BEFORE_TRADING, TRADING, AFTER_TRADING, SETTLEMENT, CLOSED

    # ========== 频率设置 ==========
    frequency: str = 'daily'
    frequency_options: Dict[str, Any] = field(default_factory=dict)

    # ========== 核心管理器 ==========
    portfolio: Optional['Portfolio'] = None
    order_manager: Optional['OrderManager'] = None
    position_manager: Optional['PositionManager'] = None
    benchmark_manager: Optional['BenchmarkManager'] = None
    # [NEW] 增加对主引擎的引用。
    # 为什么？这允许 Scheduler 等低层组件通过 context.engine 向上回调 Engine 的核心方法（如时间同步），
    # 而无需在初始化时层层传递 Engine 实例，实现了某种程度的“依赖注入”，使代码更清晰。
    engine: Optional['Engine'] = None

    # ========== 配置信息 ==========
    config: Dict[str, Any] = field(default_factory=dict)

    # ========== 用户自定义数据存储 ==========
    user_data: Dict[str, Any] = field(default_factory=dict)

    # ========== 运行状态 ==========
    is_running: bool = False
    is_paused: bool = False
    start_paused: bool = False # 新增：用于处理“启动即暂停”的功能
    was_interrupted: bool = False
    pause_requested: bool = False
    stop_requested: bool = False

    # [NEW] 时间同步请求标志位。
    # 这是“检测器-响应器”模型的核心通信机制。
    # LifecycleManager (检测器) 在发现阻塞后，会将此标志设为 True。
    # Scheduler (响应器) 会在循环中持续检查此标志。
    resync_requested: bool = False
    
    # [NEW] 当日策略是否发生错误的标志位。
    # LifecycleManager 在捕获异常时设置它，Scheduler 在新的一天开始时重置它。
    # IntegratedServer 读取它并传递给前端，用于UI告警。
    strategy_error_today: bool = False

    # ========== 可视化服务 ==========
    visualization_server: Optional['IntegratedServer'] = None

    # ========== 日志 ==========
    logger: Optional[logging.Logger] = None
    
    # ========== 数据提供者 ==========
    data_provider: Optional['AbstractDataProvider'] = None

    # ========== 每日静态信息缓存 ==========
    symbol_info_cache: Dict[str, Any] = field(default_factory=dict) 

    # ========== 盘中收益曲线 ==========
    intraday_equity_history: List[Dict[str, Any]] = field(default_factory=list)
    intraday_benchmark_history: List[Dict[str, Any]] = field(default_factory=list)
    
    # ========== 回测日志 ==========
    log_buffer: List[Dict[str, Any]] = field(default_factory=list)
    log_buffer_limit: int = 1000

    def set(self, key: str, value: Any):
        """
        在 user_data 字典中存储用户自定义数据。
        这是为了兼容旧版API，方便策略编写者使用 context.set(key, value)。
        """
        self.user_data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """
        从 user_data 字典中获取用户自定义数据。
        这是为了兼容旧版API，方便策略编写者使用 context.get(key, default_value)。
        """
        return self.user_data.get(key, default)