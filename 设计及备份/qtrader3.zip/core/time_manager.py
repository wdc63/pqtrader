# qtrader/core/time_manager.py

from datetime import datetime, time
from typing import List
from ..core.context import Context

class TimeManager:
    """
    时间管理器

    提供时间相关的工具方法，依赖用户注入的数据提供者和配置。
    """

    def __init__(self, context: Context):
        self.context = context
        trading_sessions_config = self.context.config.get('trading_sessions', [])
        
        self.parsed_sessions = [
            (
                datetime.strptime(start, '%H:%M:%S').time(),
                datetime.strptime(end, '%H:%M:%S').time()
            ) for start, end in trading_sessions_config
        ]
        self._calendar_cache = None

    def _get_full_calendar(self):
        """获取并缓存完整的交易日历"""
        if self._calendar_cache is None:
            if self.context.data_provider is None:
                raise RuntimeError("未注册数据提供者")
            start = self.context.config.get("start_date", "2005-01-01")
            end = self.context.config.get("end_date", f"{datetime.now().year+1}-12-31")
            self._calendar_cache = set(self.context.data_provider.get_trading_calendar(start, end))
        return self._calendar_cache

    def get_trading_days(self, start: str, end: str) -> List[str]:
        """
        获取指定范围内的交易日列表
        """
        full_calendar = self._get_full_calendar()
        return sorted([day for day in full_calendar if start <= day <= end])

    def is_trading_day(self, dt: datetime) -> bool:
        """
        判断是否为交易日
        """
        date_str = dt.strftime('%Y-%m-%d')
        return date_str in self._get_full_calendar()

    def is_trading_time(self, dt: datetime) -> bool:
        """
        判断是否在交易时段内
        """
        if not self.is_trading_day(dt):
            return False

        current_time = dt.time()
        for start_time, end_time in self.parsed_sessions:
            if start_time <= current_time <= end_time:
                return True
        return False