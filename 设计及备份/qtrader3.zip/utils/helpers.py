# qtrader/utils/helpers.py

import uuid

def generate_order_id() -> str:
    """
    生成一个全局唯一的订单ID。

    使用UUID4来确保在绝大多数情况下ID的唯一性。
    
    Returns:
        str: 一个字符串形式的唯一ID。
    """
    return str(uuid.uuid4())