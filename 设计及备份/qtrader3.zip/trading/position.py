# qtrader/trading/position.py

from datetime import datetime
from typing import Optional, Dict, Any
from enum import Enum

class PositionDirection(Enum):
    LONG = 'long'
    SHORT = 'short'

class Position:
    """
    持仓对象

    支持多空头寸与 T+1/T+0 规则。
    """
    def __init__(
        self,
        symbol: str,
        symbol_name: Optional[str],
        amount: int,
        avg_cost: float,
        current_dt: datetime,
        direction: PositionDirection = PositionDirection.LONG
    ):
        self.symbol: str = symbol
        self.symbol_name: Optional[str] = symbol_name
        self.direction: PositionDirection = direction
        self.total_amount: int = amount
        self.avg_cost: float = avg_cost
        self.current_price: Optional[float] = avg_cost
        self.init_time: datetime = current_dt
        self.last_update_time: datetime = current_dt
        # T+1 相关属性
        self.available_amount: int = 0
        self.today_open_amount: int = amount
        self.last_settle_price: float = avg_cost

    @property
    def market_value(self) -> float:
        if self.current_price is None:
            return 0.0
        multiplier = 1 if self.direction == PositionDirection.LONG else -1
        return multiplier * self.total_amount * self.current_price

    @property
    def unrealized_pnl(self) -> float:
        if self.current_price is None:
            return 0.0
        if self.direction == PositionDirection.LONG:
            return (self.current_price - self.avg_cost) * self.total_amount
        return (self.avg_cost - self.current_price) * self.total_amount

    @property
    def unrealized_pnl_ratio(self) -> float:
        """浮动盈亏比例"""
        if self.avg_cost == 0:
            return 0.0
        multiplier = 1 if self.direction == PositionDirection.LONG else -1
        price = self.current_price or self.avg_cost
        return multiplier * (price - self.avg_cost) / self.avg_cost

    def update_price(self, price: float):
        """更新当前价格 (由撮合引擎在结算时调用)"""
        self.current_price = price

    def open(self, amount: int, price: float, dt: datetime):
        """开仓"""
        total_cost = self.avg_cost * self.total_amount + price * amount
        self.total_amount += amount
        if self.total_amount > 0:
            self.avg_cost = total_cost / self.total_amount
        else:
            self.avg_cost = 0.0
        self.today_open_amount += amount
        self.last_update_time = dt

    def close(self, amount: int, price: float, dt: datetime) -> float:
        """平仓"""
        if amount > self.total_amount:
            raise ValueError("平仓数量大于持仓数量。")
        if self.direction == PositionDirection.LONG:
            pnl = (price - self.avg_cost) * amount
        else:
            pnl = (self.avg_cost - price) * amount
        self.total_amount -= amount
        self.available_amount = max(self.available_amount - amount, 0)
        if self.total_amount == 0:
            self.today_open_amount = 0
        self.last_update_time = dt
        return pnl
    def settle_t1(self):
        """处理T+1结算 (日终调用)"""
        self.available_amount += self.today_open_amount
        self.today_open_amount = 0

    def settle_day(self, close_price: float, date_str: str) -> Optional[Dict[str, Any]]:
        if self.total_amount == 0:
            self.last_settle_price = close_price
            self.update_price(close_price)
            return None

        prev_price = self.last_settle_price if self.last_settle_price is not None else close_price
        if self.direction == PositionDirection.LONG:
            daily_pnl = (close_price - prev_price) * self.total_amount
        else:
            daily_pnl = (prev_price - close_price) * self.total_amount

        self.last_settle_price = close_price
        self.update_price(close_price)

        base_value = abs(self.avg_cost * self.total_amount)
        daily_pnl_ratio = (daily_pnl / base_value) if base_value > 0 else 0.0

        return {
            "date": date_str,
            "symbol": self.symbol,
            "symbol_name": self.symbol_name,
            "direction": self.direction.value,
            "amount": self.total_amount,
            "close_price": close_price,
            "market_value": abs(self.total_amount * close_price),
            "daily_pnl": daily_pnl,
            "daily_pnl_ratio": daily_pnl_ratio
        }