# qtrader/trading/position_manager.py

from typing import Dict, List, Optional, Any
from datetime import datetime
from ..trading.position import Position, PositionDirection
from ..core.context import Context

class PositionManager:
    """持仓管理器，支持多空方向与每日快照。"""
    def __init__(self, context: Context):
        self.context = context
        self.positions: Dict[str, Position] = {}
        self.daily_snapshots: List[Dict[str, Any]] = []

    @staticmethod
    def _key(symbol: str, direction: PositionDirection) -> str:
        return f"{symbol}::{direction.value}"

    def get_position(self, symbol: str, direction: PositionDirection = PositionDirection.LONG) -> Optional[Position]:
        return self.positions.get(self._key(symbol, direction))

    def get_all_positions(self, direction: Optional[PositionDirection] = None) -> List[Position]:
        if direction is None:
            return list(self.positions.values())
        return [p for p in self.positions.values() if p.direction == direction]

    def _ensure_position(self, symbol: str, symbol_name: Optional[str], amount: int,
                         price: float, dt: datetime, direction: PositionDirection) -> Position:
        key = self._key(symbol, direction)
        if key not in self.positions:
            pos = Position(symbol, symbol_name, amount, price, dt, direction)
            if self.context.config.get('trading_rule', 'T+1') == 'T+0':
                pos.available_amount = pos.total_amount
                pos.today_open_amount = 0
            self.positions[key] = pos
        return self.positions[key]

    def _sync_available_after_open(self, pos: Position):
        rule = self.context.config.get('trading_rule', 'T+1')
        if rule == 'T+0':
            pos.available_amount = pos.total_amount

    def process_trade(self, order, price: float, dt: datetime, trading_mode: str) -> float:
        """
        根据成交订单更新持仓，返回实现盈亏。
        """
        realized_pnl = 0.0
        amount_remaining = order.amount
        symbol = order.symbol
        symbol_name = order.symbol_name

        rule = self.context.config.get('trading_rule', 'T+1')

        if order.side.value == 'buy':
            short_pos = self.get_position(symbol, PositionDirection.SHORT)
            if short_pos and short_pos.total_amount > 0:
                closable = short_pos.available_amount if rule == 'T+1' else short_pos.total_amount
                cover_amount = min(amount_remaining, closable)
                if cover_amount > 0:
                    realized_pnl += short_pos.close(cover_amount, price, dt)
                    amount_remaining -= cover_amount
                    if short_pos.total_amount == 0:
                        del self.positions[self._key(symbol, PositionDirection.SHORT)]

            if amount_remaining > 0:
                long_pos = self._ensure_position(symbol, symbol_name, 0, price, dt, PositionDirection.LONG)
                long_pos.open(amount_remaining, price, dt)
                self._sync_available_after_open(long_pos)

        else:  # SELL
            long_pos = self.get_position(symbol, PositionDirection.LONG)
            if long_pos and long_pos.total_amount > 0:
                closable = long_pos.available_amount if rule == 'T+1' else long_pos.total_amount
                sell_amount = min(amount_remaining, closable)
                if sell_amount > 0:
                    realized_pnl += long_pos.close(sell_amount, price, dt)
                    amount_remaining -= sell_amount
                    if long_pos.total_amount == 0:
                        del self.positions[self._key(symbol, PositionDirection.LONG)]

            if amount_remaining > 0:
                if trading_mode != 'long_short':
                    raise RuntimeError("当前设置为只做多模式，无法开空。")
                short_pos = self._ensure_position(symbol, symbol_name, 0, price, dt, PositionDirection.SHORT)
                short_pos.open(amount_remaining, price, dt)
                self._sync_available_after_open(short_pos)

        return realized_pnl

    def adjust_position(self, symbol: str, amount: int, avg_cost: float,
                        symbol_name: Optional[str] = None,
                        direction: PositionDirection = PositionDirection.LONG):
        key = self._key(symbol, direction)
        if amount <= 0:
            if key in self.positions:
                del self.positions[key]
        else:
            pos = self.positions.get(key)
            dt = self.context.current_dt or datetime.now()
            if pos:
                pos.total_amount = amount
                pos.avg_cost = avg_cost
                pos.available_amount = amount if self.context.config.get('trading_rule', 'T+1') == 'T+0' else 0
                pos.today_open_amount = 0
                pos.last_update_time = dt
            else:
                pos = Position(symbol, symbol_name, amount, avg_cost, dt, direction)
                if self.context.config.get('trading_rule', 'T+1') == 'T+0':
                    pos.available_amount = amount
                    pos.today_open_amount = 0
                self.positions[key] = pos
        self.context.logger.info(
            f"持仓已手动调整: {symbol} ({direction.value}), 数量: {amount}, 成本: {avg_cost:.2f}"
        )

    def record_daily_snapshot(self, date_str: str, entries: List[Dict[str, Any]]):
        self.daily_snapshots.append({
            "date": date_str,
            "positions": entries
        })

    def restore_positions(self, positions: List[Position]):
        self.positions = {
            self._key(pos.symbol, pos.direction): pos for pos in positions
        }

    def restore_daily_snapshots(self, snapshots: List[Dict[str, Any]]):
        self.daily_snapshots = snapshots or []