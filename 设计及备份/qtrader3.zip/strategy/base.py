# qtrader/strategy/base.py

from abc import ABC, abstractmethod
from ..core.context import Context

class Strategy(ABC):
    """
    策略基类 (Abstract Base Class)

    所有用户策略都必须继承自这个类，并实现 initialize 方法。
    其他生命周期钩子是可选的。
    """

    def __init__(self):
        """
        策略类的构造函数。
        用户可以在这里进行一些不依赖 context 的初始化操作。
        """
        pass

    @abstractmethod
    def initialize(self, context: Context):
        """
        策略初始化钩子 (必须实现)。
        在策略启动时调用一次，用于设置初始参数。
        """
        pass

    def before_trading(self, context: Context):
        """
        盘前准备钩子 (可选)。
        每日开盘前调用。
        """
        pass

    def handle_bar(self, context: Context):
        """
        核心策略逻辑钩子 (可选)。
        在盘中根据配置的频率和时间点调用。
        """
        pass

    def after_trading(self, context: Context):
        """
        盘后处理钩子 (可选)。
        每日收盘后调用。
        """
        pass

    def broker_settle(self, context: Context):
        """
        日终结算钩子 (可选)。
        在框架完成内部结算后调用，可用于与外部系统对账。
        """
        pass

    def on_end(self, context: Context):
        """
        策略结束钩子 (可选)。
        在策略运行完成或停止时调用。
        """
        pass