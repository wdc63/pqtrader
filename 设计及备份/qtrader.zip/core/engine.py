# qtrader/core/engine.py

import signal
import webbrowser
import importlib.util
import sys
from pathlib import Path
from typing import Optional, Type
from ..core.config import load_config
from ..core.context import Context
from ..core.workspace_manager import WorkspaceManager
from ..core.time_manager import TimeManager
from ..core.scheduler import Scheduler
from ..core.lifecycle import LifecycleManager
from ..strategy.base import Strategy
from ..data.interface import AbstractDataProvider
from ..trading.account import Portfolio
from ..trading.order_manager import OrderManager
from ..trading.position_manager import PositionManager
from ..trading.matching_engine import MatchingEngine
from ..benchmark.benchmark_manager import BenchmarkManager
from ..utils.logger import setup_logger
from ..utils.serializer import StateSerializer
from ..analysis.integrated_server import IntegratedServer

class Engine:
    """
    QTrader主引擎
    支持三种启动模式：
    1. run() - 全新回测
    2. resume() - 中断续行
    3. run_from_snapshot() - 回测分叉
    """

    def __init__(self, config_path: str):
        """初始化引擎"""
        self.config = load_config(config_path)
        self.config_path = config_path
        
        self.context: Optional[Context] = None
        self.workspace_manager: Optional[WorkspaceManager] = None
        self.state_serializer: Optional[StateSerializer] = None
        self.scheduler: Optional[Scheduler] = None
        self.server: Optional[IntegratedServer] = None
        
        # 临时日志记录器
        import logging
        self.temp_logger = logging.getLogger("qtrader.engine")
        if not self.temp_logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
            self.temp_logger.addHandler(handler)
            self.temp_logger.setLevel(logging.INFO)

        # 验证必需配置
        self._validate_config()

    def _validate_config(self):
        """验证配置文件必需字段"""
        required = {
            'engine.start_date': '回测开始日期',
            'engine.end_date': '回测结束日期',
            'account.initial_cash': '初始资金',
        }
        
        for field_path, description in required.items():
            keys = field_path.split('.')
            value = self.config
            for key in keys:
                value = value.get(key) if isinstance(value, dict) else None
                if value is None:
                    raise ValueError(f"配置文件缺少必需字段: {field_path} ({description})")
        
        # 验证必需字段
        engine_config = self.config.get('engine', {})
        if not engine_config.get('start_date'):
            raise ValueError("配置文件缺少必需字段: start_date")
        if not engine_config.get('end_date'):
            raise ValueError("配置文件缺少必需字段: end_date")
    
    @classmethod
    def load_from_state(cls, state_file: str, config_path: Optional[str] = None):
        """从状态文件加载引擎（用于resume和fork）"""
        import pickle
        with open(state_file, 'rb') as f:
            state = pickle.load(f)
        
        if config_path is None:
            state_path = Path(state_file)
            workspace_dir = state_path.parent
            config_snapshot = workspace_dir / "snapshot_config.yaml"
            if config_snapshot.exists():
                config_path = str(config_snapshot)
            else:
                import tempfile
                import yaml
                with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                    yaml.dump(state['context']['config'], f)
                    config_path = f.name
        
        engine = cls(config_path)
        engine._state_to_restore = state
        engine._state_file_path = state_file
        
        return engine
    
    def run(self, strategy: str, data_provider: str):
        """
        启动全新回测
        
        Args:
            strategy: 策略文件路径 (例如: 'strategies/simple_ma.py')
            data_provider: 数据提供者文件路径
        
        示例：
            engine.run(
                strategy='strategies/simple_ma.py',
                data_provider='strategies/my_data_provider.py'
            )
        """
        self.temp_logger.info("=" * 60)
        self.temp_logger.info("QTrader V4 - 启动全新回测")
        self.temp_logger.info("=" * 60)
        
        # 1. 加载数据提供者
        data_provider_instance = self._load_data_provider(data_provider)
        
        # 2. 创建工作区
        self.workspace_manager = WorkspaceManager(strategy, data_provider, self.config, self.temp_logger)
        
        # 3. 初始化上下文
        self.context = Context(config=self.config)
        self.context.engine = self
        self.context.mode = self.config.get('engine', {}).get('mode', 'backtest')
        self.context.frequency = self.config.get('engine', {}).get('frequency', 'daily')
        self.context.frequency_options = self.config.get('engine', {}).get('frequency_options', {})
        self.context.start_date = self.config.get('engine', {}).get('start_date')
        self.context.end_date = self.config.get('engine', {}).get('end_date')
        
        # 4. 设置日志
        log_config = self.config.get('logging', {})
        log_config['file'] = str(self.workspace_manager.log_file)
        self.context.logger = setup_logger(log_config, self.context)
        
        # 5. 加载策略
        strategy_class = self._load_strategy_class(strategy)
        self.context.strategy_name = self.config.get('engine', {}).get('strategy_name', strategy_class.__name__)
        
        # 6. 注入数据提供者
        self.context.data_provider = data_provider_instance
        self.context.logger.info(f"数据提供者 {type(data_provider_instance).__name__} 已注册")
        
        # 7. 初始化核心组件
        self._initialize_components(strategy_class)
        
        # 8. 启动服务器
        self._start_server_if_enabled()
        
        # 9. 注册信号处理
        self._register_signal_handlers()
        
        # 10. 运行回测
        self._execute_backtest()
    
    def resume(self, data_provider: str = None):
        """
        恢复中断的回测
        
        Args:
            data_provider: 数据提供者模块路径
        """
        self.temp_logger.info("=" * 60)
        self.temp_logger.info("QTrader V4 - 恢复中断的回测")
        self.temp_logger.info("=" * 60)
        
        if not hasattr(self, '_state_to_restore'):
            raise RuntimeError("无法恢复：未从状态文件加载引擎。请使用 Engine.load_from_state()")
        
        state = self._state_to_restore
        
        # 确定工作区
        state_path = Path(self._state_file_path)
        workspace_dir = state_path.parent
        
        # 初始化上下文
        self.context = Context(config=self.config)
        self.context.engine = self
        
        # 设置日志
        log_config = self.config.get('logging', {})
        log_config['file'] = str(workspace_dir / "backtest.log")
        self.context.logger = setup_logger(log_config, self.context)
        
        self.context.logger.info(f"从状态文件恢复: {self._state_file_path}")
        self.context.logger.info(f"保存时间: {state.get('timestamp', 'Unknown')}")
        
        # 恢复上下文状态
        context_data = state['context']
        self.context.mode = context_data['mode']
        self.context.strategy_name = context_data['strategy_name']
        self.context.start_date = context_data['start_date']
        self.context.end_date = context_data['end_date']
        self.context.current_dt = context_data['current_dt']
        self.context.frequency = context_data['frequency']
        self.context.frequency_options = context_data.get('frequency_options', {})
        self.context.user_data = state.get('user_data', {})
        
        # 恢复核心组件
        self.context.portfolio = state['portfolio']
        self.context.order_manager = OrderManager(self.context)
        self.context.order_manager.restore_orders(state.get('orders', []))
        
        self.context.position_manager = PositionManager(self.context)
        self.context.position_manager.restore_positions(state.get('positions', []))
        self.context.position_manager.restore_daily_snapshots(state.get('position_snapshots', []))
        
        benchmark_config = self.config.get('benchmark', {})
        self.context.benchmark_manager = BenchmarkManager(self.context, benchmark_config)
        self.context.benchmark_manager.benchmark_history = state.get('benchmark_history', [])
        if 'symbol' in benchmark_config and not self.context.benchmark_manager.benchmark_symbol:
            self.context.benchmark_manager.benchmark_symbol = benchmark_config['symbol']
            self.context.benchmark_manager.initial_value = state.get('benchmark_initial_value')
        
        # 加载策略
        strategy_snapshot = workspace_dir / "snapshot_code.py"
        if not strategy_snapshot.exists():
            raise FileNotFoundError(f"策略快照不存在: {strategy_snapshot}")
        strategy_instance = self._load_strategy_class(strategy_snapshot)
        
        # 加载数据
        if not data_provider:
            data_provider_snapshot = workspace_dir / "snapshot_data_provider.py"
            if not data_provider_snapshot.exists():
                raise FileNotFoundError(f"数据提供者不存在: {data_provider_snapshot}")
            data_provider_instance = self._load_data_provider(data_provider_snapshot)
        else:
            data_provider_instance = self._load_data_provider(data_provider)
        self.context.data_provider = data_provider_instance
        
        # 初始化其他组件
        matching_engine = MatchingEngine(self.context, self.config.get('matching', {}))
        time_manager = TimeManager(self.context)
        lifecycle_manager = LifecycleManager(self.context)
        lifecycle_manager.register_strategy(strategy_instance)
        
        self.scheduler = Scheduler(self.context, time_manager, matching_engine, lifecycle_manager)
        
        # 状态序列化器
        self.state_serializer = StateSerializer(self.context, str(workspace_dir))
        self.context.state_serializer = self.state_serializer
        
        # 启动服务器
        self._start_server_if_enabled()
        
        # 注册信号处理
        self._register_signal_handlers()
        
        # 继续运行
        self.context.is_running = True
        self.context.logger.info("继续运行回测...")
        
        try:
            self.scheduler.run()
        except Exception as e:
            self.context.logger.error(f"运行时发生异常: {e}", exc_info=True)
        finally:
            self._finalize()

    def run_from_snapshot(
        self, 
        strategy: str = None,
        data_provider: str = None,
        reinitialize: bool = True
    ):
        """
        从历史状态分叉出新的回测
        
        Args:
            strategy: 新策略文件路径
            data_provider: 数据提供者文件路径
            reinitialize: 是否重新初始化策略
        """
        self.temp_logger.info("=" * 60)
        self.temp_logger.info("QTrader V4 - 从快照分叉回测")
        self.temp_logger.info(f"重新初始化: {reinitialize}")
        self.temp_logger.info("=" * 60)
        
        if not hasattr(self, '_state_to_restore'):
            raise RuntimeError("无法分叉：未从状态文件加载引擎。请使用 Engine.load_from_state()")
        
        state = self._state_to_restore
        
        # 创建新工作区
        self.workspace_manager = WorkspaceManager(strategy, data_provider, self.config, self.temp_logger)
        
        # 初始化上下文
        self.context = Context(config=self.config)
        self.context.engine = self
        
        # 设置日志
        log_config = self.config.get('logging', {})
        log_config['file'] = str(self.workspace_manager.log_file)
        self.context.logger = setup_logger(log_config, self.context)
        
        self.context.logger.info(f"从状态文件分叉: {self._state_file_path}")
        self.context.logger.info(f"原保存时间: {state.get('timestamp', 'Unknown')}")
        
        # 加载策略
        if strategy:
            self.context.logger.info(f"加载新策略: {strategy}")
            strategy_class = self._load_strategy_class(strategy)
        else:
            self.context.logger.info("使用旧策略快照")
            workspace_dir = Path(self._state_file_path).parent
            strategy_snapshot = workspace_dir / "snapshot_code.py"
            if not strategy_snapshot.exists():
                raise FileNotFoundError(f"策略快照不存在: {strategy_snapshot}")
            strategy_class = self._load_strategy_class(strategy_snapshot)

        self.context.strategy_name = self.config.get('engine', {}).get('strategy_name', strategy_class.__name__)

        # 注入数据提供者
        if data_provider:
            self.context.logger.info(f"加载新数据提供者: {data_provider}")
            data_provider_instance = self._load_data_provider(data_provider)
        else:
            self.context.logger.info("使用旧数据提供者快照")
            workspace_dir = Path(self._state_file_path).parent
            data_provider_snapshot = workspace_dir / "snapshot_data_provider.py"
            if not data_provider_snapshot.exists():
                raise FileNotFoundError(f"数据提供者不存在: {data_provider_snapshot}")
            data_provider_instance = self._load_data_provider(data_provider_snapshot)
        self.context.data_provider = data_provider_instance


        # 恢复基本配置
        context_data = state['context']
        self.context.mode = self.config.get('engine', {}).get('mode', context_data['mode'])
        self.context.frequency = self.config.get('engine', {}).get('frequency', context_data['frequency'])
        self.context.frequency_options = self.config.get('engine', {}).get('frequency_options', context_data.get('frequency_options', {}))
        
        # 分叉点
        self.context.start_date = context_data['current_dt'].strftime('%Y-%m-%d')
        self.context.end_date = self.config.get('engine', {}).get('end_date', context_data['end_date'])
        self.context.current_dt = context_data['current_dt']
        
        # 恢复账户和持仓
        self.context.portfolio = state['portfolio']
        self.context.position_manager = PositionManager(self.context)
        self.context.position_manager.restore_positions(state.get('positions', []))
        self.context.position_manager.restore_daily_snapshots(state.get('position_snapshots', []))
        
        # 处理用户数据
        if reinitialize:
            self.context.user_data = {}
            self.context.logger.info("已清空旧策略的user_data")
        else:
            self.context.user_data = state.get('user_data', {})
            self.context.logger.warning("保留了旧策略的user_data - 请确保新策略兼容！")

        # 初始化其他组件
        self.context.order_manager = OrderManager(self.context)
        
        benchmark_config = self.config.get('benchmark', {})
        self.context.benchmark_manager = BenchmarkManager(self.context, benchmark_config)
        self.context.benchmark_manager.benchmark_history = state.get('benchmark_history', [])
        if 'symbol' in benchmark_config:
            self.context.benchmark_manager.benchmark_symbol = benchmark_config['symbol']
            self.context.benchmark_manager.initial_value = state.get('benchmark_initial_value')
        
        matching_engine = MatchingEngine(self.context, self.config.get('matching', {}))
        time_manager = TimeManager(self.context)
        
        # 初始化新策略
        strategy_instance = strategy_class()
        lifecycle_manager = LifecycleManager(self.context)
        lifecycle_manager.register_strategy(strategy_instance)
        
        if reinitialize:
            self.context.logger.info("调用新策略的initialize()...")
            lifecycle_manager.call_initialize()
        else:
            self.context.logger.warning("跳过initialize() - 用户需确保策略状态兼容")
        
        # 初始化调度器
        self.scheduler = Scheduler(self.context, time_manager, matching_engine, lifecycle_manager)
        
        # 状态序列化器
        self.state_serializer = StateSerializer(self.context, str(self.workspace_manager.workspace_dir))
        self.context.state_serializer = self.state_serializer
        
        # 启动服务器
        self._start_server_if_enabled()
        
        # 注册信号处理
        self._register_signal_handlers()
        
        # 运行新回测
        self.context.is_running = True
        self.context.logger.info(f"从 {self.context.start_date} 开始运行分叉回测...")
        
        try:
            self.scheduler.run(skip_initialize=(not reinitialize))
        except Exception as e:
            self.context.logger.error(f"运行时发生异常: {e}", exc_info=True)
        finally:
            self._finalize()
    
    # ========== 私有辅助方法 ==========
    
    def _load_strategy_class(self, strategy_path: str) -> Type[Strategy]:
        """动态加载策略类"""
        strategy_path = Path(strategy_path).resolve()
        
        if not strategy_path.exists():
            raise FileNotFoundError(f"策略文件不存在: {strategy_path}")
        
        # 动态导入模块
        spec = importlib.util.spec_from_file_location("user_strategy", strategy_path)
        module = importlib.util.module_from_spec(spec)
        sys.modules["user_strategy"] = module
        spec.loader.exec_module(module)
        
        # 查找Strategy子类
        strategy_class = None
        for name in dir(module):
            obj = getattr(module, name)
            if (isinstance(obj, type) and 
                issubclass(obj, Strategy) and 
                obj is not Strategy):
                strategy_class = obj
                break
        
        if strategy_class is None:
            raise ValueError(f"在 {strategy_path} 中未找到Strategy子类")
        
        self.context.logger.info(f"策略类 {strategy_class.__name__} 已加载")
        return strategy_class
    
    def _load_data_provider(self, provider_path: str) -> AbstractDataProvider:
        """
        动态加载数据提供者
        
        Args:
            provider_path: 数据提供者模块路径 (格式: 'module.path.ClassName')
                          如果为None，使用默认MockDataProvider
        
        Returns:
            数据提供者实例
        """
        
        provider_file_path = Path(provider_path).resolve()
        if not provider_file_path.exists():
            raise FileNotFoundError(f"数据提供者文件不存在: {provider_file_path}")

        # 动态导入模块
        import importlib.util
        import sys
        
        module_name = provider_file_path.stem
        spec = importlib.util.spec_from_file_location(module_name, provider_file_path)
        module = importlib.util.module_from_spec(spec)
        
        # 这一步很重要，可以防止一些循环导入问题
        sys.modules[module_name] = module 
        spec.loader.exec_module(module)
        
        # 查找 AbstractDataProvider 的子类
        from ..data.interface import AbstractDataProvider
        provider_class = None
        for name in dir(module):
            obj = getattr(module, name)
            if (isinstance(obj, type) and 
                issubclass(obj, AbstractDataProvider) and
                obj is not AbstractDataProvider):
                provider_class = obj
                break
        
        if provider_class is None:
            raise TypeError(f"在 {provider_path} 中未找到 AbstractDataProvider 的子类")
            
        print(f"已加载数据提供者: {provider_class.__name__}")
        return provider_class()
    
    def _initialize_components(self, strategy_class: Type[Strategy]):
        """初始化所有核心组件"""
        # 核心组件
        account_config = self.config.get('account', {})
        self.context.portfolio = Portfolio(account_config.get('initial_cash', 1000000))
        self.context.order_manager = OrderManager(self.context)
        self.context.position_manager = PositionManager(self.context)
        
        benchmark_config = self.config.get('benchmark', {})
        self.context.benchmark_manager = BenchmarkManager(self.context, benchmark_config)
        if 'symbol' in benchmark_config:
            self.context.benchmark_manager.initialize(benchmark_config['symbol'])
        
        matching_engine = MatchingEngine(self.context, self.config.get('matching', {}))
        
        # 策略和生命周期
        time_manager = TimeManager(self.context)
        strategy_instance = strategy_class()
        lifecycle_manager = LifecycleManager(self.context)
        lifecycle_manager.register_strategy(strategy_instance)
        
        # 调度器
        self.scheduler = Scheduler(self.context, time_manager, matching_engine, lifecycle_manager)
        
        # 状态序列化
        self.state_serializer = StateSerializer(
            self.context, 
            str(self.workspace_manager.workspace_dir)
        )
        self.context.state_serializer = self.state_serializer
    
    def _start_server_if_enabled(self):
        """启动监控服务器（如果配置启用）"""
        server_config = self.config.get('server', {})
        if server_config.get('enable', False):
            self.server = IntegratedServer(
                self.context, 
                self.workspace_manager,
                server_config
            )
            self.server.start()
            self.context.visualization_server = self.server
            
            if server_config.get('auto_open_browser', False):
                import time
                time.sleep(1)
                webbrowser.open(f"http://localhost:{server_config.get('port', 8050)}", new=2)
    
    def _register_signal_handlers(self):
        """注册信号处理器"""
        def handle_exit(signum, frame):
            self.context.logger.warning(f"接收到停止信号 ({signum})，正在优雅退出...")
            self.stop()
            if self.state_serializer:
                self.state_serializer.save(tag='interrupt')
        
        signal.signal(signal.SIGINT, handle_exit)
        signal.signal(signal.SIGTERM, handle_exit)
    
    def _execute_backtest(self):
        """执行回测主循环"""
        self.context.is_running = True
        try:
            self.scheduler.run()
        except Exception as e:
            self.context.logger.error(f"运行时发生异常: {e}", exc_info=True)
        finally:
            self._finalize()
    
    def _finalize(self):
        """回测结束后的清理工作"""
        self.context.is_running = False
        
        # 导出CSV文件
        if self.workspace_manager:
            self.context.logger.info("正在导出CSV文件...")
            self.workspace_manager.export_csv_files(self.context)
        
        # 生成报告
        report_config = self.config.get('report', {})
        self.context.logger.info("正在生成最终报告...")
        from ..analysis.report import generate_report
        if self.workspace_manager:
            generate_report(self.context, str(self.workspace_manager.report_file))
        
        # 保存最终状态
        if self.state_serializer:
            self.state_serializer.save(tag='final')
        
        # 更新服务器
        if self.server:
            self.server.update_data()
            
            server_config = self.config.get('server', {})
            if not server_config.get('auto_close', True):
                self.context.logger.info("监控服务器保持运行，可从Web界面手动关闭")
            else:
                self.server.stop()
        
        # 自动打开报告
        if report_config.get('auto_open', False) and self.workspace_manager:
            try:
                import platform
                report_path = str(self.workspace_manager.report_file)
                if platform.system() == "Windows":
                    import os
                    os.startfile(report_path)
                elif platform.system() == "Darwin":
                    import os
                    os.system(f"open '{report_path}'")
                else:
                    import os
                    os.system(f"xdg-open '{report_path}'")
            except Exception as e:
                self.context.logger.warning(f"自动打开报告失败: {e}")
        
        self.context.logger.info("引擎运行结束")
    
    def pause(self):
        """暂停回测"""
        if self.context and self.context.is_running:
            self.context.is_paused = True
            self.context.logger.info("回测已暂停")
            if self.state_serializer:
                self.state_serializer.save(tag='pause')
    
    def resume_running(self):
        """恢复运行（从暂停状态）"""
        if self.context and self.context.is_running and self.context.is_paused:
            self.context.is_paused = False
            self.context.logger.info("回测已恢复运行")
    
    def stop(self):
        """停止回测"""
        if self.context:
            self.context.is_running = False
            self.context.logger.info("回测已停止")