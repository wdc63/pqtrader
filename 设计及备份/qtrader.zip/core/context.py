# qtrader/core/context.py

from datetime import datetime
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
import logging

# 避免循环导入的类型提示
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..trading.account import Portfolio
    from ..trading.order_manager import OrderManager
    from ..trading.position_manager import PositionManager
    from ..benchmark.benchmark_manager import BenchmarkManager
    from ..analysis.integrated_server import IntegratedServer
    from ..data.interface import AbstractDataProvider

@dataclass
class Context:
    """
    全局上下文对象 (Global Context)

    这是框架中最核心的对象，以数据类的形式存在，存储了策略运行过程中的所有状态信息。
    用户可以通过context访问账户、持仓、订单等信息，也可以通过user_data字典存储自定义数据。
    """

    # ========== 基础运行信息 ==========
    mode: str = 'backtest'
    strategy_name: str = 'UnnamedStrategy'
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    current_dt: Optional[datetime] = None

    # ========== 频率设置 ==========
    frequency: str = 'daily'
    frequency_options: Dict[str, Any] = field(default_factory=dict)

    # ========== 核心管理器 ==========
    portfolio: Optional['Portfolio'] = None
    order_manager: Optional['OrderManager'] = None
    position_manager: Optional['PositionManager'] = None
    benchmark_manager: Optional['BenchmarkManager'] = None

    # ========== 配置信息 ==========
    config: Dict[str, Any] = field(default_factory=dict)

    # ========== 用户自定义数据存储 ==========
    user_data: Dict[str, Any] = field(default_factory=dict)

    # ========== 运行状态 ==========
    is_running: bool = False
    is_paused: bool = False

    # ========== 可视化服务 ==========
    visualization_server: Optional['IntegratedServer'] = None

    # ========== 日志 ==========
    logger: Optional[logging.Logger] = None
    
    # ========== 数据提供者 ==========
    data_provider: Optional['AbstractDataProvider'] = None
    
    # ========== 回测日志 ==========
    log_buffer: List[Dict[str, Any]] = field(default_factory=list)
    log_buffer_limit: int = 1000

    def get(self, key: str, default: Any = None) -> Any:
        """
        获取用户自定义数据。

        Args:
            key: 数据键名
            default: 默认值 (如果键不存在)

        Returns:
            对应的值或默认值
        """
        return self.user_data.get(key, default)

    def set(self, key: str, value: Any):
        """
        设置用户自定义数据。

        Args:
            key: 数据键名
            value: 数据值
        """
        self.user_data[key] = value