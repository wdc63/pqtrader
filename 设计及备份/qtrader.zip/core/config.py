# qtrader/core/config.py

import yaml
from typing import Dict, Any

def load_config(config_path: str) -> Dict[str, Any]:
    """
    从指定路径加载YAML配置文件。

    Args:
        config_path: YAML配置文件的路径。

    Returns:
        包含配置信息的字典。
    """
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        print(f"配置文件 {config_path} 加载成功。")
        return config
    except FileNotFoundError:
        print(f"错误: 配置文件 {config_path} 未找到。")
        raise
    except yaml.YAMLError as e:
        print(f"错误: 解析配置文件 {config_path} 失败: {e}")
        raise