# qtrader/core/workspace_manager.py

import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any
import logging


class WorkspaceManager:
    """
    工作区管理器
    
    负责为每次回测创建独立的工作区，管理所有文件产物。
    确保每次回测都是自包含的、可追溯的原子单元。
    """

    def __init__(self, strategy_path: str, data_provider_path: str,config: Dict[str, Any], logger: logging.Logger):
        """
        Args:
            strategy_path: 策略文件路径
            config: 配置字典
            logger: 日志记录器
        """
        self.strategy_path = Path(strategy_path).resolve()
        self.config = config
        self.logger = logger
        
        # 提取策略名称
        self.strategy_name = self.strategy_path.stem
        
        # 确定根目录
        workspace_config = config.get('workspace', {})
        root_dir = workspace_config.get('root_dir')
        
        if root_dir:
            self.root_dir = Path(root_dir).resolve()
        else:
            # 默认在策略文件旁创建同名目录
            self.root_dir = self.strategy_path.parent / self.strategy_name
        
        # 创建时间戳工作区
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.workspace_dir = self.root_dir / "backtest" / timestamp
        
        # 确保工作区存在
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger.info(f"工作区已创建: {self.workspace_dir}")
        
        # 创建快照
        self._create_snapshots()
    
    def _create_snapshots(self):
        """创建代码和配置文件的快照"""
        workspace_config = self.config.get('workspace', {})
        
        # 代码快照
        if workspace_config.get('create_code_snapshot', True):
            try:
                snapshot_code = self.workspace_dir / f"snapshot_code.py"
                shutil.copy2(self.strategy_path, snapshot_code)
                self.logger.info(f"策略代码快照已创建: {snapshot_code.name}")
            except Exception as e:
                self.logger.warning(f"创建代码快照失败: {e}")
        
        # 配置快照
        if workspace_config.get('create_config_snapshot', True):
            try:
                import yaml
                snapshot_config = self.workspace_dir / "snapshot_config.yaml"
                with open(snapshot_config, 'w', encoding='utf-8') as f:
                    yaml.dump(self.config, f, allow_unicode=True, default_flow_style=False)
                self.logger.info(f"配置快照已创建: {snapshot_config.name}")
            except Exception as e:
                self.logger.warning(f"创建配置快照失败: {e}")
        
        # 数据提供者快照
        if workspace_config.get('create_data_provider_snapshot', True):
            try:
                import yaml
                snapshot_data_provider = self.workspace_dir / "snapshot_data_provider.py"
                with open(snapshot_data_provider, 'w', encoding='utf-8') as f:
                    yaml.dump(self.config, f, allow_unicode=True, default_flow_style=False)
                self.logger.info(f"数据提供者快照已创建: {snapshot_data_provider.name}")
            except Exception as e:
                self.logger.warning(f"创建数据提供者快照失败: {e}")
    
    def get_path(self, filename: str) -> Path:
        """
        获取工作区内文件的完整路径
        
        Args:
            filename: 文件名
            
        Returns:
            完整路径
        """
        return self.workspace_dir / filename
    
    @property
    def log_file(self) -> Path:
        """日志文件路径"""
        return self.get_path("backtest.log")
    
    @property
    def state_file(self) -> Path:
        """状态文件路径"""
        return self.get_path("state.pkl")
    
    @property
    def report_file(self) -> Path:
        """报告文件路径"""
        return self.get_path("report.html")
    
    @property
    def equity_csv(self) -> Path:
        """权益曲线CSV路径"""
        return self.get_path("equity.csv")
    
    @property
    def positions_csv(self) -> Path:
        """每日持仓CSV路径"""
        return self.get_path("daily_positions.csv")
    
    @property
    def orders_csv(self) -> Path:
        """订单流水CSV路径"""
        return self.get_path("orders.csv")
    
    @property
    def pnl_pairs_csv(self) -> Path:
        """交易对CSV路径"""
        return self.get_path("pnl_pairs.csv")
    
    def export_csv_files(self, context):
        """
        导出所有CSV文件
        
        Args:
            context: 全局上下文
        """
        import pandas as pd
        
        # 1. 权益曲线
        if context.portfolio.history:
            equity_df = pd.DataFrame(context.portfolio.history)
            equity_df.to_csv(self.equity_csv, index=False, encoding='utf-8-sig')
            self.logger.info(f"权益曲线已导出: {self.equity_csv.name}")
        
        # 2. 每日持仓
        if context.position_manager.daily_snapshots:
            positions_data = []
            for snapshot in context.position_manager.daily_snapshots:
                date = snapshot['date']
                for pos in snapshot['positions']:
                    positions_data.append({
                        'date': date,
                        **pos
                    })
            if positions_data:
                positions_df = pd.DataFrame(positions_data)
                positions_df.to_csv(self.positions_csv, index=False, encoding='utf-8-sig')
                self.logger.info(f"每日持仓已导出: {self.positions_csv.name}")
        
        # 3. 订单流水
        all_orders = context.order_manager.get_all_orders()
        if all_orders:
            orders_data = []
            for order in all_orders:
                orders_data.append({
                    'id': order.id,
                    'symbol': order.symbol,
                    'symbol_name': order.symbol_name,
                    'side': order.side.value,
                    'amount': order.amount,
                    'order_type': order.order_type.value,
                    'limit_price': order.limit_price,
                    'status': order.status.value,
                    'created_time': order.created_time.isoformat() if order.created_time else None,
                    'filled_time': order.filled_time.isoformat() if order.filled_time else None,
                    'filled_price': order.filled_price,
                    'commission': order.commission,
                })
            orders_df = pd.DataFrame(orders_data)
            orders_df.to_csv(self.orders_csv, index=False, encoding='utf-8-sig')
            self.logger.info(f"订单流水已导出: {self.orders_csv.name}")
        
        # 4. 交易对
        from qtrader.analysis.performance import PerformanceAnalyzer
        analyzer = PerformanceAnalyzer(context)
        if not analyzer.pnl_df.empty:
            pnl_df = analyzer.pnl_df.copy()
            # 格式化时间列
            if 'entry_time' in pnl_df.columns:
                pnl_df['entry_time'] = pnl_df['entry_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            if 'exit_time' in pnl_df.columns:
                pnl_df['exit_time'] = pnl_df['exit_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            pnl_df.to_csv(self.pnl_pairs_csv, index=False, encoding='utf-8-sig')
            self.logger.info(f"交易对已导出: {self.pnl_pairs_csv.name}")