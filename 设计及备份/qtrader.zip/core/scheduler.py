# qtrader/core/scheduler.py

import time as time_module
from datetime import datetime, timedelta
from typing import List
from qtrader.core.context import Context
from qtrader.core.time_manager import TimeManager
from qtrader.core.lifecycle import LifecycleManager
from qtrader.trading.matching_engine import MatchingEngine


class Scheduler:
    """
    事件调度器 (V4)
    
    支持暂停/恢复功能，性能优先设计。
    """

    def __init__(
        self,
        context: Context,
        time_manager: TimeManager,
        matching_engine: MatchingEngine,
        lifecycle_manager: LifecycleManager
    ):
        self.context = context
        self.time_manager = time_manager
        self.matching_engine = matching_engine
        self.lifecycle_manager = lifecycle_manager
        
        # 从新配置结构获取参数
        engine_config = context.config.get('engine', {})
        self.config = context.config
        
        # 生命周期配置
        self.lifecycle_config = self.config.get('lifecycle', {})
        
        # 服务器配置
        self.server_config = self.config.get('server', {})
        self._server_enabled = self.server_config.get('enable', False)
        self._update_interval = self.server_config.get('update_interval', 1.0)
        
        # 构建回测时间点
        self._schedule_points = self._build_schedule_points()

    def run(self, skip_initialize: bool = False):
        """
        主运行循环
        
        Args:
            skip_initialize: 是否跳过initialize调用（用于分叉模式）
        """
        if self.context.mode == 'backtest':
            self._run_backtest(skip_initialize)
        else:
            self._run_simulation(skip_initialize)

    def _run_backtest(self, skip_initialize: bool = False):
        """回测模式运行循环"""
        # 初始化策略
        if not skip_initialize:
            self.lifecycle_manager.call_initialize()
        
        # 获取交易日历
        start_date = self.context.config.get('engine', {}).get('start_date')
        end_date = self.context.config.get('engine', {}).get('end_date')
        trading_days = self.time_manager.get_trading_days(start_date, end_date)
        
        # 如果是从中断恢复，从当前日期开始
        if self.context.current_dt:
            current_date = self.context.current_dt.strftime('%Y-%m-%d')
            trading_days = [d for d in trading_days if d >= current_date]
            self.context.logger.info(f"从 {current_date} 继续回测")
        
        total_days = len(trading_days)
        self.context.logger.info(f"回测开始，共 {total_days} 个交易日")

        # 生命周期时间配置
        hooks = self.lifecycle_config.get('hooks', {})
        before_trading_time = hooks.get('before_trading', '09:15:00')
        after_trading_time = hooks.get('after_trading', '15:05:00')
        broker_settle_time = hooks.get('broker_settle', '15:30:00')

        for idx, date_str in enumerate(trading_days):
            # 检查运行状态
            if not self.context.is_running:
                self.context.logger.info("回测被手动停止")
                break
            
            # 暂停检查
            while self.context.is_paused:
                time_module.sleep(0.1)
                if not self.context.is_running:
                    break
            
            if not self.context.is_running:
                break

            self.context.logger.info(f"--- 交易日: {date_str} ({idx + 1}/{total_days}) ---")

            # 1. 盘前
            dt_before_trading = datetime.strptime(
                f"{date_str} {before_trading_time}", "%Y-%m-%d %H:%M:%S"
            )
            self.context.current_dt = dt_before_trading
            self.lifecycle_manager.call_before_trading()
            self._maybe_update_server()

            # 2. 盘中
            for time_str in self._schedule_points:
                if not self.context.is_running:
                    break
                
                # 暂停检查
                while self.context.is_paused:
                    time_module.sleep(0.1)
                    if not self.context.is_running:
                        break
                
                if not self.context.is_running:
                    break
                
                dt_bar = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S")
                self.context.current_dt = dt_bar
                self.lifecycle_manager.call_handle_bar()
                self.matching_engine.match_orders(dt_bar)
                self._maybe_update_server()
            
            if not self.context.is_running:
                break

            # 3. 盘后
            dt_after_trading = datetime.strptime(
                f"{date_str} {after_trading_time}", "%Y-%m-%d %H:%M:%S"
            )
            self.context.current_dt = dt_after_trading
            self.lifecycle_manager.call_after_trading()
            self._maybe_update_server()

            # 4. 结算
            dt_settle = datetime.strptime(
                f"{date_str} {broker_settle_time}", "%Y-%m-%d %H:%M:%S"
            )
            self.context.current_dt = dt_settle
            self.matching_engine.settle()
            self.lifecycle_manager.call_broker_settle()
            self.context.benchmark_manager.update_daily()
            
            # 日终更新
            self._maybe_update_server()
            
            # 自动保存状态（可选）
            if self.context.config.get('workspace', {}).get('auto_save_state', False):
                if (idx + 1) % 10 == 0:  # 每10天保存一次
                    if self.context.state_serializer:
                        self.context.state_serializer.save(tag=f'day_{idx+1}')

        # 策略结束
        self.lifecycle_manager.call_on_end()
        self.context.logger.info("回测结束")

    def _maybe_update_server(self):
        """如果服务器启用，更新数据（性能优先：异步、有间隔）"""
        if self._server_enabled and self.context.visualization_server:
            # 异步更新，不阻塞
            self.context.visualization_server.trigger_update()
            # 微小延迟确保前端有时间处理
            time_module.sleep(min(0.01, self._update_interval / 10))

    def _run_simulation(self, skip_initialize: bool = False):
        """模拟盘模式（预留接口）"""
        self.context.logger.info("模拟盘模式尚未完全实现")
        if not skip_initialize:
            self.lifecycle_manager.call_initialize()
        # TODO: 实现模拟盘逻辑

    def _build_schedule_points(self) -> List[str]:
        """构建盘中时间点列表"""
        freq = self.context.frequency
        
        if freq == 'daily':
            hooks = self.lifecycle_config.get('hooks', {})
            handle_bar_time = hooks.get('handle_bar', '14:55:00')
            return [handle_bar_time] if isinstance(handle_bar_time, str) else handle_bar_time

        schedule = []
        sessions = self.lifecycle_config.get('trading_sessions', [])

        for start_str, end_str in sessions:
            current_dt = datetime.strptime(start_str, '%H:%M:%S')
            end_dt = datetime.strptime(end_str, '%H:%M:%S')

            delta = timedelta(minutes=1) if freq == 'minute' else timedelta(seconds=3)

            while current_dt <= end_dt:
                schedule.append(current_dt.strftime('%H:%M:%S'))
                current_dt += delta

        return sorted(list(set(schedule)))