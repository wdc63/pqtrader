# utils/serializer.py

import pickle
import os
from datetime import datetime
from typing import Optional
from ..core.context import Context

class StateSerializer:
    """
    状态序列化器
    
    负责保存和加载策略运行状态。
    
    保存内容：
        - context: 策略运行的上下文信息（如模式、策略名、起止日期、当前时间、频率、配置等）
        - portfolio: 当前投资组合信息
        - positions: 当前持仓信息
        - position_snapshots: 持仓每日快照
        - orders: 所有订单信息
        - benchmark_history: 基准历史数据
        - user_data: 用户自定义数据
        - timestamp: 保存时间戳
    """
    
    def __init__(self, context: Context, save_dir: str = '.states'):
        """
        Args:
            context: 全局上下文
            save_dir: 状态保存目录
        """
        self.context = context
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)
    
    def save(self, tag: Optional[str] = None):
        """
        保存当前状态
        
        Args:
            tag: 标签（默认使用当前日期）
        """
        if tag is None:
            tag = self.context.current_dt.strftime('%Y%m%d')

        file_path = os.path.join(
            self.save_dir,
            f"{self.context.strategy_name}_{tag}.pkl"
        )
        
        # 收集状态
        state = {
            'context': {
                'mode': self.context.mode,
                'strategy_name': self.context.strategy_name,
                'start_date': self.context.start_date,
                'end_date': self.context.end_date,
                'current_dt': self.context.current_dt,
                'frequency': self.context.frequency,
                'frequency_options': self.context.frequency_options,
                'config': self.context.config,
            },
            'portfolio': self.context.portfolio,
            'positions': self.context.position_manager.get_all_positions(),
            'position_snapshots': self.context.position_manager.daily_snapshots,
            'orders': self.context.order_manager.get_all_orders(),
            'benchmark_history': self.context.benchmark_manager.benchmark_history,
            'user_data': self.context.user_data,
            'timestamp': datetime.now().isoformat()
        }
        
        # 序列化
        with open(file_path, 'wb') as f:
            pickle.dump(state, f)
        
        self.context.logger.info(f"状态已保存到 {file_path}")
    
    def load(self, file_path: str):
        """
        加载状态
        
        Args:
            file_path: 状态文件路径
        """
        with open(file_path, 'rb') as f:
            state = pickle.load(f)
        
        # 恢复Context基本信息
        context_data = state['context']
        self.context.mode = context_data['mode']
        self.context.strategy_name = context_data['strategy_name']
        self.context.start_date = context_data['start_date']
        self.context.end_date = context_data['end_date']
        self.context.current_dt = context_data['current_dt']
        self.context.frequency = context_data['frequency']
        self.context.frequency_options = context_data.get('frequency_options', {})
        self.context.config = context_data['config']
        
        # 恢复Portfolio
        self.context.portfolio = state['portfolio']
        
        # 恢复Positions
        self.context.position_manager.restore_positions(state['positions'])
        self.context.position_manager.restore_daily_snapshots(state.get('position_snapshots', []))
        
        # 恢复Orders
        self.context.order_manager.restore_orders(state['orders'])
        
        # 恢复Benchmark
        self.context.benchmark_manager.benchmark_history = state['benchmark_history']
        
        # 恢复user_data
        self.context.user_data = state['user_data']
        
        self.context.logger.info(f"状态已从 {file_path} 加载")
        self.context.logger.info(f"保存时间: {state['timestamp']}")