# qtrader/utils/logger.py

import logging
import sys
from typing import Dict, Any, Optional
from datetime import datetime


class InMemoryLogHandler(logging.Handler):
    """
    将日志写入 Context.log_buffer，便于实时监控展示。
    """
    def __init__(self, context, capacity: int):
        super().__init__()
        self.context = context
        self.capacity = capacity

    def emit(self, record: logging.LogRecord):
        if self.context is None:
            return
        msg = self.format(record)

        if self.context.mode == 'backtest' and getattr(self.context, 'current_dt', None):
            timestamp = self.context.current_dt.isoformat(timespec='seconds')
        else:
            timestamp = datetime.fromtimestamp(record.created).isoformat(timespec='seconds')

        entry = {
            "timestamp": timestamp,
            "level": record.levelname,
            "message": msg
        }
        self.context.log_buffer.append(entry)
        overflow = len(self.context.log_buffer) - self.capacity
        if overflow > 0:
            del self.context.log_buffer[:overflow]


def setup_logger(config: Dict[str, Any], context=None) -> logging.Logger:
    """
    根据配置初始化并返回一个日志记录器。

    Args:
        config (Dict[str, Any]): 日志配置字典，来自YAML文件。
        context (Optional[Context]): 可选的Context实例，用于将日志写入内存。

    Returns:
        logging.Logger: 配置好的日志记录器实例。
    """
    logger = logging.getLogger("qtrader")
    logger.propagate = False

    if logger.hasHandlers():
        logger.handlers.clear()

    level = getattr(logging, config.get('level', 'INFO').upper(), logging.INFO)
    logger.setLevel(level)

    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    if config.get('console_output', True):
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(level)
        ch.setFormatter(formatter)
        logger.addHandler(ch)

    log_file = config.get('file')
    if log_file:
        try:
            fh = logging.FileHandler(log_file, mode='a', encoding='utf-8')
            fh.setLevel(level)
            fh.setFormatter(formatter)
            logger.addHandler(fh)
        except Exception as e:
            logger.error(f"无法创建日志文件 {log_file}: {e}")

    buffer_size = config.get('buffer_size', 1000)
    if context is not None:
        context.log_buffer_limit = buffer_size
        memory_handler = InMemoryLogHandler(context, buffer_size)
        memory_handler.setLevel(level)
        memory_handler.setFormatter(formatter)
        logger.addHandler(memory_handler)

    return logger