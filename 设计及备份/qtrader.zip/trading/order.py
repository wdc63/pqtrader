# qtrader/trading/order.py

from datetime import datetime
from typing import Optional
from enum import Enum
from dataclasses import dataclass, field
from qtrader.utils.helpers import generate_order_id

class OrderSide(Enum):
    """订单方向"""
    BUY = 'buy'
    SELL = 'sell'

class OrderType(Enum):
    """订单类型"""
    MARKET = 'market'
    LIMIT = 'limit'

class OrderStatus(Enum):
    """订单状态"""
    OPEN = 'open'
    FILLED = 'filled'
    REJECTED = 'rejected'
    CANCELLED = 'cancelled'
    EXPIRED = 'expired'

@dataclass
class Order:
    """
    订单对象

    表示一个交易订单，包含订单的所有信息和状态。
    """
    symbol: str
    amount: int
    side: OrderSide
    order_type: OrderType
    limit_price: Optional[float] = None
    symbol_name: Optional[str] = None

    # 由系统自动生成的属性
    id: str = field(default_factory=generate_order_id)
    status: OrderStatus = OrderStatus.OPEN
    created_time: Optional[datetime] = None
    created_bar_time: Optional[datetime] = None
    filled_time: Optional[datetime] = None
    filled_price: Optional[float] = None
    commission: Optional[float] = None
    is_immediate: bool = True

    def fill(self, price: float, commission: float, dt: datetime):
        """标记订单为已成交"""
        self.status = OrderStatus.FILLED
        self.filled_price = price
        self.commission = commission
        self.filled_time = dt

    def reject(self, reason: str = ""):
        """标记订单为已拒绝"""
        self.status = OrderStatus.REJECTED

    def cancel(self) -> bool:
        """标记订单为已撤销"""
        if self.status == OrderStatus.OPEN:
            self.status = OrderStatus.CANCELLED
            return True
        return False

    def expire(self):
        """标记订单为已过期"""
        if self.status == OrderStatus.OPEN:
            self.status = OrderStatus.EXPIRED

    def mark_as_historical(self):
        """标记订单为历史订单"""
        self.is_immediate = False