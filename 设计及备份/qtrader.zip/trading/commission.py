# qtrader/trading/commission.py

from typing import Dict
from qtrader.trading.order import Order, OrderSide

class CommissionCalculator:
    """手续费计算器"""
    def __init__(self, config: Dict):
        self.buy_commission = config.get('buy_commission', 0.0002)
        self.sell_commission = config.get('sell_commission', 0.0002)
        self.buy_tax = config.get('buy_tax', 0.0)
        self.sell_tax = config.get('sell_tax', 0.001)
        self.min_commission = config.get('min_commission', 5.0)

    def calculate(self, order: Order, price: float) -> float:
        total_value = price * order.amount
        if order.side == OrderSide.BUY:
            commission = total_value * self.buy_commission
            tax = total_value * self.buy_tax
        else:
            commission = total_value * self.sell_commission
            tax = total_value * self.sell_tax
        
        commission = max(commission, self.min_commission)
        return commission + tax

