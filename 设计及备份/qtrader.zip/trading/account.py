# qtrader/trading/account.py

from typing import List, Dict, Any
from datetime import datetime

class Portfolio:
    """
    账户对象

    管理账户的现金、总资产、历史净值等信息。
    """
    def __init__(self, initial_cash: float):
        """
        Args:
            initial_cash (float): 初始资金
        """
        self.initial_cash: float = initial_cash
        self.cash: float = initial_cash          # 当前可用现金
        self.total_value: float = initial_cash   # 当前总资产 (现金 + 持仓市值)
        self.history: List[Dict[str, Any]] = []  # 历史净值记录

    def record_history(self, dt: datetime, position_value: float):
        """
        记录当日账户状态 (在每日结算时由撮合引擎调用)。

        Args:
            dt (datetime): 当前日期时间
            position_value (float): 当前总持仓市值
        """
        self.total_value = self.cash + position_value
        self.history.append({
            'date': dt.strftime('%Y-%m-%d'),
            'cash': self.cash,
            'position_value': position_value,
            'total_value': self.total_value,
            'returns': self.returns,
        })

    @property
    def returns(self) -> float:
        """计算当前累计收益率"""
        if self.initial_cash == 0:
            return 0.0
        return (self.total_value - self.initial_cash) / self.initial_cash