from datetime import datetime
from typing import Dict, Optional, List
from qtrader.core.context import Context
from qtrader.trading.order import Order, OrderStatus, OrderSide, OrderType
from qtrader.trading.commission import CommissionCalculator
from qtrader.trading.slippage import SlippageModel
from qtrader.trading.position import PositionDirection

class MatchingEngine:
    """撮合引擎，支持多空交易。"""
    def __init__(self, context: Context, config: dict):
        self.context = context
        self.config = config
        self.commission_calc = CommissionCalculator(config.get('commission', {}))
        self.slippage_model = SlippageModel(config.get('slippage', {}))
        self.trading_mode = context.config.get('trading_mode', 'long_only')

    def match_orders(self, dt: datetime):
        open_orders = self.context.order_manager.get_open_orders()
        immediate = [o for o in open_orders if o.is_immediate]
        historical = [o for o in open_orders if not o.is_immediate]

        for order in immediate:
            self._try_match_immediate(order, dt)

        for order in historical:
            self._try_match_historical(order, dt)

    def _try_match_immediate(self, order: Order, dt: datetime):
        snapshot = self._get_snapshot(order.symbol, dt)
        if not snapshot:
            order.mark_as_historical()
            return

        if not self._pre_check(order, snapshot):
            return

        match_price = self._determine_immediate_match_price(order, snapshot)
        if match_price is None:
            order.mark_as_historical()
            return

        self._execute_match_flow(order, match_price, snapshot, dt)

    def _try_match_historical(self, order: Order, dt: datetime):
        snapshot = self._get_snapshot(order.symbol, dt)
        if not snapshot:
            return
        if snapshot.get('is_suspended', False):
            return

        current_price = snapshot.get('current_price')
        can_match = False
        if order.side == OrderSide.BUY and current_price is not None:
            if order.order_type == OrderType.MARKET or current_price <= order.limit_price:
                can_match = True
        elif order.side == OrderSide.SELL and current_price is not None:
            if order.order_type == OrderType.MARKET or current_price >= order.limit_price:
                can_match = True

        if can_match:
            match_price = current_price if order.order_type == OrderType.MARKET else order.limit_price
            self._execute_match_flow(order, match_price, snapshot, dt)

    def _execute_match_flow(self, order: Order, match_price: float, snapshot: Dict, dt: datetime):
        # 1. 计算加滑点后的价格
        slippage = self.slippage_model.calculate(order, match_price)
        final_price = match_price + slippage if order.side == OrderSide.BUY else match_price - slippage

        if not self._check_limit_price_range(final_price, snapshot, order.side):
            order.reject("加滑点后超出涨跌停范围")
            return
        # 2. 计算手续费
        commission = self.commission_calc.calculate(order, final_price)

        check_result = self._check_sufficiency(order, final_price, commission)
        if not check_result:
            order.reject("资金/持仓不足")
            return 
        # 3. 成交
        self._finalize_trade(order, final_price, commission, dt)

    def _determine_immediate_match_price(self, order: Order, snapshot: Dict) -> Optional[float]:
        price_ref = snapshot.get('current_price')
        ask1, bid1 = snapshot.get('ask1'), snapshot.get('bid1')

        if order.order_type == OrderType.MARKET:
            if order.side == OrderSide.BUY:
                return ask1 if ask1 else price_ref
            return bid1 if bid1 else price_ref

        if order.order_type == OrderType.LIMIT:
            if order.side == OrderSide.BUY:
                market_price = ask1 if ask1 else price_ref
                if market_price is None:
                    return None
                if order.limit_price >= market_price:
                    return market_price
            else:
                market_price = bid1 if bid1 else price_ref
                if market_price is None:
                    return None
                if order.limit_price <= market_price:
                    return market_price
        return None

    def _get_snapshot(self, symbol: str, dt: datetime) -> Optional[Dict]:
        snapshot = self.context.data_provider.get_current_snapshot(symbol, dt, self.context.frequency)
        if not snapshot:
            self.context.logger.warning(f"无法获取 {symbol} 在 {dt} 的价格快照。")
        return snapshot

    def _pre_check(self, order: Order, snapshot: Dict) -> bool:
        if order.symbol_name is None:
            order.symbol_name = snapshot.get('symbol_name')

        if snapshot.get('is_suspended', False):
            order.reject("标的停牌")
            return False

        current, high, low = snapshot.get('current_price'), snapshot.get('high_limit'), snapshot.get('low_limit')
        if current is None:
            order.reject("缺少当前价格")
            return False

        if (order.side == OrderSide.BUY and high and abs(current - high) < 1e-6) or \
           (order.side == OrderSide.SELL and low and abs(current - low) < 1e-6):
            order.reject("当前价触及涨跌停")
            return False
        return True

    def _check_limit_price_range(self, price: float, snapshot: Dict, side: OrderSide) -> bool:
        high, low = snapshot.get('high_limit'), snapshot.get('low_limit')
        if high is not None and low is not None:
            return low <= price <= high
        return True

    def _check_sufficiency(self, order: Order, price: float, commission: float) -> bool:
        portfolio = self.context.portfolio
        pm = self.context.position_manager
        rule = self.context.config.get('trading_rule', 'T+1')

        if order.side == OrderSide.BUY:
            cash_needed = price * order.amount + commission
            if portfolio.cash >= cash_needed:
                return True
            short_pos = pm.get_position(order.symbol, PositionDirection.SHORT)
            if short_pos and short_pos.total_amount > 0:
                max_cover = short_pos.available_amount if rule == 'T+1' else short_pos.total_amount
                if max_cover >= order.amount:
                    return True
            return False

        # SELL
        long_pos = pm.get_position(order.symbol, PositionDirection.LONG)
        if long_pos and long_pos.total_amount > 0:
            available = long_pos.available_amount if rule == 'T+1' else long_pos.total_amount
            if available >= order.amount:
                return True

        if self.trading_mode == 'long_short':
            return True

        return False

    def _finalize_trade(self, order: Order, price: float, commission: float, dt: datetime):
        order.fill(price, commission, dt)
        self.context.order_manager.add_filled_order_to_history(order)

        pm = self.context.position_manager
        portfolio = self.context.portfolio

        gross_value = price * order.amount
        trading_mode = self.context.config.get('trading_mode', 'long_only')
        realized_pnl = pm.process_trade(order, price, dt, trading_mode)

        if order.side == OrderSide.BUY:
            portfolio.cash -= gross_value + commission
        else:
            portfolio.cash += gross_value - commission

        if realized_pnl != 0:
            self.context.logger.info(
                f"成交[{order.side.value.upper()}] {order.symbol} 数量:{order.amount} "
                f"价格:{price:.2f} 实现盈亏: {realized_pnl - commission:.2f}"
            )
        else:
            self.context.logger.info(
                f"成交[{order.side.value.upper()}] {order.symbol} 数量:{order.amount} 价格:{price:.2f}"
            )

    def settle(self):
        """每日结算"""
        self.context.logger.info("开始每日结算...")
        # 1 取消未成交订单
        for order in self.context.order_manager.get_open_orders():
            order.expire()

        self.context.order_manager.clear_today_orders()
        
        # 2 结算
        pm = self.context.position_manager
        total_pos_value = 0.0
        date_str = self.context.current_dt.strftime('%Y-%m-%d')
        snapshot_entries: List[Dict] = []

        for pos in pm.get_all_positions():
            daily_bar = self.context.data_provider.get_daily_bar(pos.symbol, date_str)
            if daily_bar and 'close' in daily_bar:
                settle_entry = pos.settle_day(daily_bar['close'], date_str)
                if settle_entry:
                    snapshot_entries.append(settle_entry)
                    total_pos_value += settle_entry['market_value'] if pos.direction == PositionDirection.LONG else -settle_entry['market_value']
            else:
                self.context.logger.warning(f"无法获取 {pos.symbol} 在 {date_str} 的收盘价。")

            if self.config.get('trading_rule', 'T+1') == 'T+1':
                pos.settle_t1()

        pm.record_daily_snapshot(date_str, snapshot_entries)
        self.context.portfolio.record_history(self.context.current_dt, total_pos_value)
        self.context.logger.info(f"结算完成, 总资产: {self.context.portfolio.total_value:.2f}")