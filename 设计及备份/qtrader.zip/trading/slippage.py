# qtrader/trading/slippage.py

from typing import Dict
from qtrader.trading.order import Order

class SlippageModel:
    """滑点模型"""
    def __init__(self, config: Dict):
        self.type = config.get('type', 'fixed')
        self.rate = config.get('rate', 0.001)

    def calculate(self, order: Order, price: float) -> float:
        if self.type == 'fixed':
            return price * self.rate
        return 0.0