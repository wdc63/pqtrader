# qtrader/data/interface.py

from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from datetime import datetime

class AbstractDataProvider(ABC):
    """
    抽象数据提供者 (AbstractDataProvider)

    这是框架与数据层之间的接口合约。用户必须实现这个抽象基类。
    """
    
    @abstractmethod
    def get_trading_calendar(self, start: str, end: str) -> List[str]:
        """
        获取交易日历。返回 [ 'YYYY-MM-DD', ... ] 格式的列表。
        """
        pass
    
    @abstractmethod
    def get_current_snapshot(
        self, symbol: str, dt: datetime, frequency: str
    ) -> Optional[Dict]:
        """
        获取当前时刻的价格快照。
        返回格式:
        {
            'symbol_name': str (可选),
            'current_price': float (必须),
            'ask1': float (可选),
            'bid1': float (可选),
            'high_limit': float (可选),
            'low_limit': float (可选),
            'is_suspended': bool (可选),
        }
        """
        pass
    
    @abstractmethod
    def get_daily_bar(self, symbol: str, date: str) -> Optional[Dict[str, float]]:
        """
        获取单日行情数据 (OHLC)。
        返回格式: {'open': float, 'close': float}
        """
        pass