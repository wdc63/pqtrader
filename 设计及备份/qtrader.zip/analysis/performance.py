# qtrader/analysis/performance.py

from collections import defaultdict, deque
from typing import Dict, Any, List
import pandas as pd
import numpy as np
from qtrader.core.context import Context
from qtrader.trading.order import OrderSide

class PerformanceAnalyzer:
    """
    交易性能分析器 (V4)

    基于FIFO原则配对交易，计算包含手续费的净利润。
    """
    def __init__(self, context: Context):
        self.context = context
        self.pnl_df = self._calculate_pnl()

    def _calculate_pnl(self) -> pd.DataFrame:
        filled_orders = sorted(
            self.context.order_manager.get_all_orders_history(),
            key=lambda o: o.filled_time
        )
        
        long_entries: Dict[str, deque] = defaultdict(deque)
        short_entries: Dict[str, deque] = defaultdict(deque)
        trade_pairs = []
        
        for order in filled_orders:
            symbol = order.symbol
            # 简化 entry_struct，我们只需要 order 对象本身
            entry_struct = {"order": order, "remaining": order.amount}
            
            if order.side == OrderSide.BUY:
                remaining = entry_struct["remaining"]
                queue = short_entries[symbol]
                
                # 平空仓
                while remaining > 0 and queue:
                    short_entry = queue[0]
                    trade_amount = min(short_entry["remaining"], remaining)
                    
                    # >>>>> 简化后的手续费逻辑 <<<<<
                    # 按比例分配手续费
                    entry_commission = short_entry["order"].commission * (trade_amount / short_entry["order"].amount)
                    exit_commission = order.commission * (trade_amount / order.amount)
                    total_commission = entry_commission + exit_commission
                    
                    gross_pnl = (short_entry["order"].filled_price - order.filled_price) * trade_amount
                    net_pnl = gross_pnl - total_commission
                    
                    trade_pairs.append({
                        "symbol": symbol,
                        "symbol_name": order.symbol_name or short_entry["order"].symbol_name,
                        "direction": "short",
                        "entry_time": short_entry["order"].filled_time,
                        "exit_time": order.filled_time,
                        "entry_price": short_entry["order"].filled_price,
                        "exit_price": order.filled_price,
                        "amount": trade_amount,
                        "total_commission": total_commission,
                        "gross_pnl": gross_pnl,
                        "net_pnl": net_pnl
                    })
                    
                    remaining -= trade_amount
                    short_entry["remaining"] -= trade_amount
                    if short_entry["remaining"] == 0:
                        queue.popleft()
                
                # 开多仓
                if remaining > 0:
                    long_entries[symbol].append(entry_struct)
            
            else:  # SELL
                # 平多仓
                remaining = entry_struct["remaining"]
                queue = long_entries[symbol]
                while remaining > 0 and queue:
                    long_entry = queue[0]
                    trade_amount = min(long_entry["remaining"], remaining)
                    
                    entry_commission = long_entry["order"].commission * (trade_amount / long_entry["order"].amount)
                    exit_commission = order.commission * (trade_amount / order.amount)
                    total_commission = entry_commission + exit_commission

                    gross_pnl = (order.filled_price - long_entry["order"].filled_price) * trade_amount
                    net_pnl = gross_pnl - total_commission

                    trade_pairs.append({
                        "symbol": symbol,
                        "symbol_name": order.symbol_name or long_entry["order"].symbol_name,
                        "direction": "long",
                        "entry_time": long_entry["order"].filled_time,
                        "exit_time": order.filled_time,
                        "entry_price": long_entry["order"].filled_price,
                        "exit_price": order.filled_price,
                        "amount": trade_amount,
                        "total_commission": total_commission,
                        "gross_pnl": gross_pnl,
                        "net_pnl": net_pnl
                    })
                    
                    remaining -= trade_amount
                    long_entry["remaining"] -= trade_amount
                    if long_entry["remaining"] == 0:
                        queue.popleft()
                # 开空仓
                if remaining > 0:
                    short_entries[symbol].append(entry_struct)
        
        if not trade_pairs:
            return pd.DataFrame()
        
        df = pd.DataFrame(trade_pairs)
        
        # 计算盈亏率（基于净利润）
        df['net_pnl_ratio'] = np.where(
            df['entry_price'] * df['amount'] != 0,
            df['net_pnl'] / (df['entry_price'] * df['amount']),
            0.0
        )
        
        # 计算持仓天数
        df['hold_days'] = (df['exit_time'] - df['entry_time']).dt.days
        
        return df

    @property
    def summary(self) -> List[Dict[str, Any]]:
        """
        生成包含手续费的性能指标摘要
        """
        if self.pnl_df.empty:
            return [{"message": "没有完成的交易对。"}]

        pnl = self.pnl_df
        total_trades = len(pnl)
        
        # 使用净利润计算
        winning_trades = pnl[pnl['net_pnl'] > 0]
        losing_trades = pnl[pnl['net_pnl'] < 0]

        net_profit = pnl['net_pnl'].sum()
        gross_profit = winning_trades['net_pnl'].sum()
        gross_loss = abs(losing_trades['net_pnl'].sum())
        total_commission = pnl['total_commission'].sum()
        
        win_rate = len(winning_trades) / total_trades if total_trades > 0 else 0
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else np.inf
        
        avg_win = winning_trades['net_pnl'].mean() if len(winning_trades) > 0 else 0
        avg_loss = abs(losing_trades['net_pnl'].mean()) if len(losing_trades) > 0 else 0
        win_loss_ratio = avg_win / avg_loss if avg_loss > 0 else np.inf
        
        max_win_val = pnl['net_pnl'].max() if not pnl.empty else 0
        max_loss_val = pnl['net_pnl'].min() if not pnl.empty else 0
        
        avg_hold_days = pnl['hold_days'].mean()
        
        metrics = [
            {"key": "净利润", "value": f"{net_profit:,.2f}", "raw": net_profit},
            {"key": "总盈利", "value": f"{gross_profit:,.2f}", "raw": gross_profit},
            {"key": "总亏损", "value": f"{gross_loss:,.2f}", "raw": -gross_loss},
            {"key": "总手续费", "value": f"{total_commission:,.2f}", "raw": -total_commission},
            {"key": "利润因子", "value": f"{profit_factor:.2f}", "raw": profit_factor},
            {"key": "总交易次数", "value": str(total_trades), "raw": 0},
            {"key": "盈利次数", "value": str(len(winning_trades)), "raw": len(winning_trades)},
            {"key": "亏损次数", "value": str(len(losing_trades)), "raw": -len(losing_trades)},
            {"key": "胜率", "value": f"{win_rate:.2%}", "raw": win_rate},
            {"key": "平均盈利", "value": f"{avg_win:,.2f}", "raw": avg_win},
            {"key": "平均亏损", "value": f"{avg_loss:,.2f}", "raw": -avg_loss},
            {"key": "盈亏比", "value": f"{win_loss_ratio:.2f}", "raw": win_loss_ratio},
            {"key": "最大单笔盈利", "value": f"{max_win_val:,.2f}", "raw": max_win_val},
            {"key": "最大单笔亏损", "value": f"{max_loss_val:,.2f}", "raw": max_loss_val},
            {"key": "平均持仓天数", "value": f"{avg_hold_days:.2f}", "raw": avg_hold_days}
        ]
        return metrics