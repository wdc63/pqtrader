# qtrader/analysis/integrated_server.py

import threading
import time
from pathlib import Path
from typing import Dict, Any, Optional, List
from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from qtrader.core.context import Context
from qtrader.core.workspace_manager import WorkspaceManager
import pandas as pd


class WorkspaceFileHandler(FileSystemEventHandler):
    """工作区文件变化监听器"""
    
    def __init__(self, server):
        self.server = server
        self.last_update = time.time()
        self.update_cooldown = 0.5  # 防抖：500ms内只触发一次
    
    def on_modified(self, event):
        if event.is_directory:
            return
        
        # 只关心特定文件
        filename = Path(event.src_path).name
        if filename in ['backtest.log', 'equity.csv', 'daily_positions.csv', 
                       'orders.csv', 'pnl_pairs.csv', 'state.pkl']:
            current_time = time.time()
            if current_time - self.last_update > self.update_cooldown:
                self.last_update = current_time
                self.server.trigger_update()


class IntegratedServer:
    """
    集成监控服务器 (V4)
    
    功能：
    1. 文件监控：异步监控工作区文件变化
    2. Web服务：提供实时监控界面
    3. 控制接口：接收前端控制命令
    """
    
    def __init__(
        self, 
        context: Context, 
        workspace_manager: WorkspaceManager,
        config: Dict[str, Any]
    ):
        self.context = context
        self.workspace_manager = workspace_manager
        self.config = config
        
        # Flask应用
        self.app = Flask(
            __name__,
            template_folder=str(Path(__file__).parent / 'templates'),
            static_folder=str(Path(__file__).parent / 'static')
        )
        self.socketio = SocketIO(self.app, cors_allowed_origins="*")
        
        # 文件监控
        self.observer = Observer()
        self.file_handler = WorkspaceFileHandler(self)
        
        # 线程控制
        self.server_thread: Optional[threading.Thread] = None
        self.update_lock = threading.Lock()
        self.should_update = False
        
        # 设置路由
        self._setup_routes()
        
        # 设置SocketIO事件
        self._setup_socketio()
    
    def _setup_routes(self):
        """设置Flask路由"""
        
        @self.app.route('/')
        def index():
            """主监控页面"""
            return render_template('integrated_monitor.html')
        
        @self.app.route('/api/overview')
        def get_overview():
            """获取概览数据"""
            return jsonify(self._collect_overview_data())
        
        @self.app.route('/api/performance')
        def get_performance():
            """获取交易表现数据"""
            return jsonify(self._collect_performance_data())
        
        @self.app.route('/api/positions')
        def get_positions():
            """获取持仓数据"""
            return jsonify(self._collect_positions_data())
        
        @self.app.route('/api/orders')
        def get_orders():
            """获取订单数据"""
            return jsonify(self._collect_orders_data())
        
        @self.app.route('/api/logs')
        def get_logs():
            """获取日志数据"""
            return jsonify(self._collect_logs_data())
        
        @self.app.route('/api/snapshots')
        def get_snapshots():
            """获取代码快照"""
            return jsonify(self._collect_snapshots_data())
        
        @self.app.route('/api/download/<filename>')
        def download_file(filename):
            """下载文件"""
            from flask import send_file
            file_path = self.workspace_manager.workspace_dir / filename
            if file_path.exists():
                return send_file(str(file_path), as_attachment=True)
            return jsonify({'error': 'File not found'}), 404
        
        @self.app.route('/api/control', methods=['POST'])
        def control():
            """控制接口"""
            data = request.get_json()
            action = data.get('action')
            
            if action == 'pause':
                self.context.engine.pause()
                return jsonify({'status': 'paused'})
            elif action == 'resume':
                self.context.engine.resume_running()
                return jsonify({'status': 'resumed'})
            elif action == 'stop':
                self.context.engine.stop()
                return jsonify({'status': 'stopped'})
            elif action == 'shutdown_server':
                self.stop()
                return jsonify({'status': 'server_shutdown'})
            
            return jsonify({'error': 'Unknown action'}), 400
    
    def _setup_socketio(self):
        """设置SocketIO事件"""
        
        @self.socketio.on('connect')
        def handle_connect():
            self.context.logger.info("前端已连接")
            # 立即推送当前数据
            self.trigger_update()
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            self.context.logger.info("前端已断开")
    
    def start(self):
        """启动服务器"""
        port = self.config.get('port', 8050)
        
        # 启动文件监控
        workspace_dir = str(self.workspace_manager.workspace_dir)
        self.observer.schedule(self.file_handler, workspace_dir, recursive=False)
        self.observer.start()
        self.context.logger.info(f"文件监控已启动: {workspace_dir}")
        
        # 启动Web服务器
        self.server_thread = threading.Thread(
            target=lambda: self.socketio.run(
                self.app,
                host='0.0.0.0',
                port=port,
                debug=False,
                use_reloader=False,
                log_output=False
            ),
            daemon=True
        )
        self.server_thread.start()
        
        self.context.logger.info(f"监控服务器已启动: http://localhost:{port}")
    
    def stop(self):
        """停止服务器"""
        self.observer.stop()
        self.observer.join()
        self.context.logger.info("监控服务器已停止")
    
    def trigger_update(self):
        """触发数据更新（异步、防抖）"""
        with self.update_lock:
            self.should_update = True
            # 启动更新线程
            threading.Thread(target=self._do_update, daemon=True).start()
    
    def _do_update(self):
        """执行更新（在后台线程中）"""
        time.sleep(0.05)  # 小延迟确保文件写入完成
        
        with self.update_lock:
            if not self.should_update:
                return
            self.should_update = False
        
        try:
            data = {
                'overview': self._collect_overview_data(),
                'performance': self._collect_performance_data(),
                'positions': self._collect_positions_data(),
                'orders': self._collect_orders_data(),
                'logs': self._collect_logs_data(),
                'timestamp': time.time()
            }
            self.socketio.emit('update', data)
        except Exception as e:
            self.context.logger.error(f"更新数据失败: {e}")
    
    # ========== 数据收集方法 ==========
    
    def _collect_overview_data(self) -> Dict[str, Any]:
        """收集概览数据"""
        portfolio = self.context.portfolio
        
        # 计算持仓市值
        positions_value = 0.0
        for pos in self.context.position_manager.get_all_positions():
            multiplier = 1 if pos.direction.value == 'long' else -1
            positions_value += multiplier * (pos.market_value or 0.0)
        
        # 基准数据
        benchmark_returns = 0.0
        benchmark_value = portfolio.initial_cash
        if self.context.benchmark_manager:
            benchmark_returns = self.context.benchmark_manager.get_current_returns()
            benchmark_value = self.context.benchmark_manager.get_current_value()
        
        # 权益曲线
        equity_data = self._read_equity_csv()
        
        return {
            'strategy_name': self.context.strategy_name,
            'mode': self.context.mode,
            'frequency': self.context.frequency,
            'current_dt': self.context.current_dt.isoformat() if self.context.current_dt else None,
            'is_running': self.context.is_running,
            'is_paused': self.context.is_paused,
            'start_date': self.context.start_date,
            'end_date': self.context.end_date,
            'portfolio': {
                'total_value': portfolio.total_value,
                'cash': portfolio.cash,
                'positions_value': positions_value,
                'returns': portfolio.returns,
                'initial_cash': portfolio.initial_cash,
            },
            'benchmark': {
                'returns': benchmark_returns,
                'value': benchmark_value,
            },
            'equity_curve': equity_data,
            'risk_metrics': self._calculate_risk_metrics(),
        }
    
    def _collect_performance_data(self) -> Dict[str, Any]:
        """收集交易表现数据"""
        pnl_data = self._read_pnl_csv()
        
        from qtrader.analysis.performance import PerformanceAnalyzer
        analyzer = PerformanceAnalyzer(self.context)
        
        return {
            'trade_metrics': analyzer.summary,
            'pnl_pairs': pnl_data,
        }
    
    def _collect_positions_data(self) -> Dict[str, Any]:
        """收集持仓数据"""
        positions_data = self._read_positions_csv()
        
        return {
            'daily_positions': positions_data,
        }
    
    def _collect_orders_data(self) -> Dict[str, Any]:
        """收集订单数据"""
        orders_data = self._read_orders_csv()
        
        return {
            'orders': orders_data,
        }
    
    def _collect_logs_data(self) -> Dict[str, Any]:
        """收集日志数据"""
        logs = []
        log_file = self.workspace_manager.log_file
        
        if log_file.exists():
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    # 只返回最后1000行
                    for line in lines[-1000:]:
                        logs.append({'message': line.strip()})
            except Exception as e:
                self.context.logger.error(f"读取日志文件失败: {e}")
        
        return {'logs': logs}
    
    def _collect_snapshots_data(self) -> Dict[str, Any]:
        """收集代码快照数据"""
        code_snapshot = ""
        config_snapshot = ""
        
        code_file = self.workspace_manager.workspace_dir / "snapshot_code.py"
        if code_file.exists():
            try:
                with open(code_file, 'r', encoding='utf-8') as f:
                    code_snapshot = f.read()
            except Exception as e:
                self.context.logger.error(f"读取代码快照失败: {e}")
        
        config_file = self.workspace_manager.workspace_dir / "snapshot_config.yaml"
        if config_file.exists():
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    config_snapshot = f.read()
            except Exception as e:
                self.context.logger.error(f"读取配置快照失败: {e}")
        
        return {
            'code': code_snapshot,
            'config': config_snapshot,
        }
    
    # ========== CSV读取辅助方法 ==========
    
    def _read_equity_csv(self) -> List[Dict]:
        """读取权益曲线CSV"""
        csv_file = self.workspace_manager.equity_csv
        if csv_file.exists():
            try:
                df = pd.read_csv(csv_file)
                return df.to_dict('records')
            except Exception as e:
                self.context.logger.error(f"读取权益曲线CSV失败: {e}")
        return []
    
    def _read_pnl_csv(self) -> List[Dict]:
        """读取交易对CSV"""
        csv_file = self.workspace_manager.pnl_pairs_csv
        if csv_file.exists():
            try:
                df = pd.read_csv(csv_file)
                return df.to_dict('records')
            except Exception as e:
                self.context.logger.error(f"读取交易对CSV失败: {e}")
        return []
    
    def _read_positions_csv(self) -> List[Dict]:
        """读取持仓CSV"""
        csv_file = self.workspace_manager.positions_csv
        if csv_file.exists():
            try:
                df = pd.read_csv(csv_file)
                # 按日期分组
                result = []
                for date in df['date'].unique():
                    date_df = df[df['date'] == date]
                    result.append({
                        'date': date,
                        'positions': date_df.to_dict('records')
                    })
                return result
            except Exception as e:
                self.context.logger.error(f"读取持仓CSV失败: {e}")
        return []
    
    def _read_orders_csv(self) -> List[Dict]:
        """读取订单CSV"""
        csv_file = self.workspace_manager.orders_csv
        if csv_file.exists():
            try:
                df = pd.read_csv(csv_file)
                return df.to_dict('records')
            except Exception as e:
                self.context.logger.error(f"读取订单CSV失败: {e}")
        return []
    
    def _calculate_risk_metrics(self) -> List[Dict[str, Any]]:
        """计算风险指标"""
        try:
            history_df = pd.DataFrame(self.context.portfolio.history)
            if len(history_df) < 2:
                return [{"message": "历史数据不足，无法计算风险指标。"}]

            import empyrical as em
            returns = history_df['total_value'].pct_change().dropna()
            
            benchmark_history = pd.DataFrame(self.context.benchmark_manager.get_benchmark_data())
            benchmark_returns = benchmark_history.get('value', pd.Series(dtype=float)).pct_change().dropna()

            returns.index = pd.to_datetime(history_df['date'].iloc[1:])
            if not benchmark_history.empty and 'date' in benchmark_history:
                benchmark_returns.index = pd.to_datetime(benchmark_history['date'].iloc[1:])
                returns, benchmark_returns = returns.align(benchmark_returns, join='inner')
            else:
                benchmark_returns = returns.copy() * 0

            if len(returns) < 2:
                return [{"message": "对齐后的收益率数据不足。"}]

            annual_return = em.annual_return(returns)
            cum_return = em.cum_returns_final(returns)
            benchmark_annual_return = em.annual_return(benchmark_returns)
            annual_volatility = em.annual_volatility(returns)
            sharpe_ratio = em.sharpe_ratio(returns)
            max_drawdown = em.max_drawdown(returns)
            calmar_ratio = em.calmar_ratio(returns)
            alpha, beta = em.alpha_beta(returns, benchmark_returns)

            metrics = [
                {"key": "年化收益率", "value": f"{annual_return:.2%}", "raw": annual_return},
                {"key": "累计收益率", "value": f"{cum_return:.2%}", "raw": cum_return},
                {"key": "基准年化收益率", "value": f"{benchmark_annual_return:.2%}", "raw": benchmark_annual_return},
                {"key": "年化波动率", "value": f"{annual_volatility:.2%}", "raw": annual_volatility},
                {"key": "夏普比率", "value": f"{sharpe_ratio:.2f}", "raw": sharpe_ratio},
                {"key": "最大回撤", "value": f"{max_drawdown:.2%}", "raw": max_drawdown},
                {"key": "卡玛比率", "value": f"{calmar_ratio:.2f}", "raw": calmar_ratio},
                {"key": "阿尔法", "value": f"{alpha:.3f}", "raw": alpha},
                {"key": "贝塔", "value": f"{beta:.3f}", "raw": beta},
            ]
            return metrics
        except Exception as e:
            self.context.logger.error(f"计算风险指标失败: {e}")
            return [{"message": f"计算失败: {str(e)}"}]