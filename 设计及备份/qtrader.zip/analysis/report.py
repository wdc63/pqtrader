# qtrader/analysis/report.py

import os
import platform
from pathlib import Path
from typing import Dict, Any, List
import pandas as pd
from jinja2 import Environment, FileSystemLoader, select_autoescape
import empyrical as em

from qtrader.core.context import Context
from qtrader.analysis.performance import PerformanceAnalyzer


def _calculate_risk_metrics(context: Context) -> List[Dict[str, Any]]:
    """计算风险指标"""
    history_df = pd.DataFrame(context.portfolio.history)
    if len(history_df) < 2:
        return [{"message": "历史数据不足，无法计算风险指标。"}]

    returns = history_df['total_value'].pct_change().dropna()
    benchmark_history = pd.DataFrame(context.benchmark_manager.get_benchmark_data())
    benchmark_returns = benchmark_history.get('value', pd.Series(dtype=float)).pct_change().dropna()

    returns.index = pd.to_datetime(history_df['date'].iloc[1:])
    if not benchmark_history.empty and 'date' in benchmark_history:
        benchmark_returns.index = pd.to_datetime(benchmark_history['date'].iloc[1:])
        returns, benchmark_returns = returns.align(benchmark_returns, join='inner')
    else:
        benchmark_returns = returns.copy() * 0

    if len(returns) < 2:
        return [{"message": "对齐后的收益率数据不足。"}]

    annual_return = em.annual_return(returns)
    cum_return = em.cum_returns_final(returns)
    benchmark_annual_return = em.annual_return(benchmark_returns)
    annual_volatility = em.annual_volatility(returns)
    sharpe_ratio = em.sharpe_ratio(returns)
    max_drawdown = em.max_drawdown(returns)
    calmar_ratio = em.calmar_ratio(returns)
    alpha, beta = em.alpha_beta(returns, benchmark_returns)

    metrics = [
        {"key": "年化收益率", "value": f"{annual_return:.2%}", "raw": annual_return},
        {"key": "累计收益率", "value": f"{cum_return:.2%}", "raw": cum_return},
        {"key": "基准年化收益率", "value": f"{benchmark_annual_return:.2%}", "raw": benchmark_annual_return},
        {"key": "年化波动率", "value": f"{annual_volatility:.2%}", "raw": annual_volatility},
        {"key": "夏普比率", "value": f"{sharpe_ratio:.2f}", "raw": sharpe_ratio},
        {"key": "最大回撤", "value": f"{max_drawdown:.2%}", "raw": max_drawdown},
        {"key": "卡玛比率", "value": f"{calmar_ratio:.2f}", "raw": calmar_ratio},
        {"key": "阿尔法", "value": f"{alpha:.3f}", "raw": alpha},
        {"key": "贝塔", "value": f"{beta:.3f}", "raw": beta},
    ]
    return metrics


def _prepare_chart_data(context: Context) -> Dict[str, Any]:
    """准备权益曲线数据"""
    portfolio_history = pd.DataFrame(context.portfolio.history)
    benchmark_history = pd.DataFrame(context.benchmark_manager.get_benchmark_data())

    if portfolio_history.empty:
        return {}

    dates = portfolio_history['date'].tolist()
    strategy_values = portfolio_history['total_value'].round(2).tolist()
    initial_cash = context.portfolio.initial_cash

    benchmark_map = {row['date']: row['value'] for _, row in benchmark_history.iterrows()} if not benchmark_history.empty else {}
    benchmark_values = [round(benchmark_map.get(d, initial_cash), 2) for d in dates]

    return {
        "dates": dates,
        "strategy_values": strategy_values,
        "benchmark_values": benchmark_values,
        "initial_cash": initial_cash,
    }


def generate_report(context: Context, output_path: str = None):
    """
    生成多标签页HTML报告
    
    Args:
        context: 上下文
        output_path: 输出路径（如果不提供，使用默认路径）
    """
    context.logger.info("开始生成回测报告...")
    
    # 计算指标
    risk_metrics = _calculate_risk_metrics(context)
    perf_analyzer = PerformanceAnalyzer(context)
    trade_metrics = perf_analyzer.summary
    
    # 准备交易对数据
    pnl_df = perf_analyzer.pnl_df.copy()
    if not pnl_df.empty:
        if 'entry_time' in pnl_df.columns:
            pnl_df['entry_time'] = pnl_df['entry_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
        if 'exit_time' in pnl_df.columns:
            pnl_df['exit_time'] = pnl_df['exit_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
    pnl_records = pnl_df.to_dict('records')

    # 准备权益曲线
    chart_data = _prepare_chart_data(context)
    
    # 准备持仓快照数据
    positions_snapshots = []
    for snapshot in context.position_manager.daily_snapshots:
        positions_snapshots.append({
            'date': snapshot['date'],
            'positions': snapshot['positions']
        })
    
    # 准备订单数据
    all_orders = context.order_manager.get_all_orders()
    orders_data = []
    for order in sorted(all_orders, key=lambda o: o.filled_time or o.created_time or context.current_dt, reverse=True):
        orders_data.append({
            'id': order.id,
            'symbol': order.symbol,
            'symbol_name': order.symbol_name,
            'side': order.side.value,
            'amount': order.amount,
            'order_type': order.order_type.value,
            'status': order.status.value,
            'created_time': order.created_time.strftime('%Y-%m-%d %H:%M:%S') if order.created_time else '-',
            'filled_time': order.filled_time.strftime('%Y-%m-%d %H:%M:%S') if order.filled_time else '-',
            'filled_price': order.filled_price,
            'commission': order.commission,
        })

    # 加载模板
    template_path = Path(__file__).parent / "templates"
    env = Environment(
        loader=FileSystemLoader(str(template_path)), 
        autoescape=select_autoescape(['html', 'xml'])
    )
    template = env.get_template('integrated_monitor.html')

    # 渲染HTML
    html_content = template.render(
        strategy_name=context.strategy_name,
        start_date=context.start_date,
        end_date=context.end_date,
        initial_cash=f"{context.config.get('account', {}).get('initial_cash', 0):,}",
        risk_metrics=risk_metrics,
        trade_metrics=trade_metrics,
        pnl_records=pnl_records,
        chart_data=chart_data,
        positions_snapshots=positions_snapshots,
        orders_data=orders_data,
    )

    # 保存文件
    if output_path is None:
        output_dir = "reports"
        os.makedirs(output_dir, exist_ok=True)
        current_dt = context.current_dt or pd.to_datetime(context.end_date)
        report_date = pd.to_datetime(current_dt).strftime('%Y%m%d')
        file_name = f"{context.strategy_name}_report_{report_date}.html"
        output_path = os.path.join(output_dir, file_name)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    context.logger.info(f"回测报告已生成: {output_path}")

    # 自动打开
    report_config = context.config.get('report', {})
    if report_config.get('auto_open', False):
        try:
            if platform.system() == "Windows":
                os.startfile(output_path)
            elif platform.system() == "Darwin":
                os.system(f"open '{output_path}'")
            else:
                os.system(f"xdg-open '{output_path}'")
        except Exception as e:
            context.logger.warning(f"自动打开报告失败: {e}")