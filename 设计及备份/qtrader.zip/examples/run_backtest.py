# examples/run_backtest.py
# python -m qtrader.examples.run_backtest

"""
QTrader V4 运行示例
"""

from qtrader.runner.backtest_runner import BacktestRunner

if __name__ == '__main__':
    # 方式1: 通过命令行运行
    # cd runner
    # python run_backtest.py --config config.yaml --strategy my_strategy.py
    
    # 方式2: 通过代码运行
    runner = BacktestRunner()
    
    # 获取当前脚本目录
    import os
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(current_dir, 'strategies','backtest.yaml')
    strategy_path = os.path.join(current_dir, 'strategies', 'simple_ma.py')
    data_provider_path = os.path.join(current_dir, 'mock_api_provider.py')
    
    # 全新回测
    runner.run([
        '--config', config_path,
        '--strategy', strategy_path,
        '--data-provider', data_provider_path 
    ])
    
    # 或者恢复回测
    # runner.run([
    #     '--config', 'configs/backtest_template.yaml',
    #     '--resume', 'path/to/state.pkl'
    # ])
    
    # 或者分叉回测
    # runner.run([
    #     '--config', 'configs/backtest_template.yaml',
    #     '--fork', 'path/to/state.pkl',
    #     '--strategy', 'strategies/optimized_strategy.py'
    # ])