# qtrader/benchmark/benchmark_manager.py

from typing import List, Dict, Optional
from qtrader.core.context import Context

class BenchmarkManager:
    """基准管理器"""
    def __init__(self, context: Context, config: Dict):
        self.context = context
        self.config = config
        self.benchmark_symbol: Optional[str] = None
        self.benchmark_history: List[Dict] = []
        self.initial_value: Optional[float] = None

    def initialize(self, symbol: str):
        self.benchmark_symbol = symbol
        start_date = self.context.start_date
        daily_bar = self.context.data_provider.get_daily_bar(symbol, start_date)
        
        if daily_bar and 'open' in daily_bar and daily_bar['open'] is not None:
            self.initial_value = daily_bar['open']
        else:
            self.initial_value = 1000.0
            self.context.logger.warning(f"无法获取基准 {symbol} 初始价格, 设为默认值 {self.initial_value}")
        
        self.context.logger.info(f"基准初始化: {symbol}, 初始价格: {self.initial_value:.2f}")

    def update_daily(self):
        if not self.benchmark_symbol: return
        
        date_str = self.context.current_dt.strftime('%Y-%m-%d')
        daily_bar = self.context.data_provider.get_daily_bar(self.benchmark_symbol, date_str)

        if daily_bar and 'close' in daily_bar and daily_bar['close'] is not None:
            close_price = daily_bar['close']
            returns = (close_price - self.initial_value) / self.initial_value if self.initial_value else 0
            value = self.context.portfolio.initial_cash * (1 + returns)
            
            self.benchmark_history.append({
                'date': date_str,
                'close_price': close_price,
                'returns': returns,
                'value': value,
            })
        else:
            self.context.logger.warning(f"无法获取基准 {self.benchmark_symbol} 在 {date_str} 的收盘价。")

    def get_current_returns(self) -> float:
        return self.benchmark_history[-1]['returns'] if self.benchmark_history else 0.0

    def get_current_value(self) -> float:
        return self.benchmark_history[-1]['value'] if self.benchmark_history else self.context.portfolio.initial_cash

    def get_benchmark_data(self) -> List[Dict]:
        return self.benchmark_history