# qtrader/runner/backtest_runner.py

import argparse
import sys
from pathlib import Path
from qtrader.core.engine import Engine


class BacktestRunner:
    """
    回测启动器 (V4)

    # 使用方法
    # 类调用：
    runner.run([
        '--config', config_path,
        '--strategy', strategy_path,
        '--data-provider', data_provider_path 
    ])
    
    # 参数运行：
    python -m qtrader.runner.backtest_runner

    1. 全新回测: --config + --strategy
    2. 恢复回测: --config + --resume
    3. 替换策略分叉回测: --config + --fork + --strategy [--no-reinit]
    """
    
    def __init__(self):
        self.parser = self._create_parser()
    
    def _create_parser(self) -> argparse.ArgumentParser:
        """创建命令行参数解析器"""
        parser = argparse.ArgumentParser(
            description='QTrader V4 - 专业量化回测框架',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
示例用法:

  # 启动全新回测
  python -m qtrader.runner.backtest_runner --config config.yaml --strategy my_strategy.py --data-provider my_data_provider.py

  # 恢复中断的回测
  python -m qtrader.runner.backtest_runner --config config.yaml --resume path/to/state.pkl 

  # 从快照分叉（默认重新初始化）
  python -m qtrader.runner.backtest_runner --config config.yaml --fork path/to/state.pkl --strategy new_strategy.py --data-provider new_data_provider.py

  # 从快照分叉（高级：不重新初始化）
  python -m qtrader.runner.backtest_runner --config config.yaml --fork path/to/state.pkl --strategy optimized.py --data-provider new_data_provider.py --no-reinit
            """
        )
        
        # 必需参数
        parser.add_argument(
            '--config',
            type=str,
            required=True,
            help='配置文件路径 (YAML格式)'
        )
        
        # 数据提供者
        parser.add_argument(
            '--data-provider',
            type=str,
            default=None,
            help='数据提供者文件路径 (格式: module.path.ClassName)'
        )
        
        # 运行模式参数（互斥）
        mode_group = parser.add_mutually_exclusive_group(required=True)
        
        mode_group.add_argument(
            '--strategy',
            type=str,
            help='策略文件路径 (用于全新回测或分叉回测)'
        )
        
        mode_group.add_argument(
            '--resume',
            type=str,
            metavar='STATE_FILE',
            help='状态文件路径 (用于恢复中断的回测)'
        )
        
        # 分叉模式参数
        parser.add_argument(
            '--fork',
            type=str,
            metavar='STATE_FILE',
            help='状态文件路径 (用于从快照分叉回测，需配合--strategy使用)'
        )
        
        parser.add_argument(
            '--no-reinit',
            action='store_true',
            help='分叉时不重新初始化策略 (高级用户功能，需确保策略兼容)'
        )
        
        return parser
    
    def run(self, args=None):
        """
        运行回测
        Args:
            args: 命令行参数列表（用于测试，默认None表示从sys.argv读取）
        """
        parsed_args = self.parser.parse_args(args)

        # 验证参数组合
        if parsed_args.fork and not parsed_args.strategy:
            self.parser.error("--fork 必须与 --strategy 一起使用")
        if parsed_args.no_reinit and not parsed_args.fork:
            self.parser.error("--no-reinit 只能在 --fork 模式下使用")

        try:
            # 根据模式启动
            if parsed_args.resume:
                self._run_resume(parsed_args)
            elif parsed_args.fork:
                self._run_fork(parsed_args)
            else:
                self._run_new(parsed_args)
        except KeyboardInterrupt:
            print("\n用户中断运行")
            sys.exit(0)
        except Exception as e:
            print(f"\n运行失败: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            sys.exit(1)
    
    def _run_new(self, args):
        """启动全新回测"""
        print("=" * 60)
        print("QTrader V4 - 启动全新回测")
        print("=" * 60)
        print(f"配置文件: {args.config}")
        print(f"策略文件: {args.strategy}")
        print("=" * 60)

        engine = Engine(args.config)
        engine.run(args.strategy, args.data_provider)
    
    def _run_resume(self, args):
        """恢复中断的回测"""
        print("=" * 60)
        print("QTrader V4 - 恢复中断的回测")
        print("=" * 60)
        print(f"配置文件: {args.config}")
        print(f"状态文件: {args.resume}")
        print("=" * 60)

        engine = Engine.load_from_state(args.resume, args.config)
        engine.resume(args.data_provider)
    
    def _run_fork(self, args):
        """从快照分叉回测"""
        reinitialize = not args.no_reinit

        print("=" * 60)
        print("QTrader V4 - 从快照分叉回测")
        print("=" * 60)
        print(f"配置文件: {args.config}")
        print(f"状态文件: {args.fork}")
        print(f"新策略文件: {args.strategy}")
        print(f"新数据提供者文件: {args.data_provider}")
        print(f"重新初始化: {'是' if reinitialize else '否 (高级模式)'}")
        print("=" * 60)

        if not reinitialize:
            print("\n⚠️  警告: 您选择了不重新初始化策略")
            print("请确保新策略能够兼容旧策略的内部状态！")
            print()

        engine = Engine.load_from_state(args.fork, args.config)
        engine.run_from_snapshot(args.strategy, args.data_provider, reinitialize=reinitialize)

def main():
    """主入口函数"""
    runner = BacktestRunner()
    runner.run()

if __name__ == '__main__':
    main()