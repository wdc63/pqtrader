# qtrader/core/lifecycle.py

from typing import Optional
from ..core.context import Context
from ..strategy.base import Strategy

class LifecycleManager:
    """
    生命周期管理器

    安全地调用策略的各个生命周期钩子，处理钩子不存在的情况。
    """

    def __init__(self, context: Context):
        self.context = context
        self.strategy: Optional[Strategy] = None

    def register_strategy(self, strategy: Strategy):
        self.strategy = strategy

    def _call_hook(self, hook_name: str):
        """
        通用钩子调用函数。

        Args:
            hook_name: 钩子方法的名称 (例如 'initialize')
        """
        if self.strategy is None:
            self.context.logger.error("错误: 策略对象未注册。")
            return

        hook_method = getattr(self.strategy, hook_name, None)
        if callable(hook_method):
            try:
                self.context.logger.debug(f"调用策略钩子: {hook_name}()")
                hook_method(self.context)
            except Exception as e:
                self.context.logger.error(f"执行策略钩子 {hook_name}() 时发生错误: {e}", exc_info=True)
                self.context.is_running = False # 发生严重错误时停止运行

    def call_initialize(self):
        self._call_hook('initialize')

    def call_before_trading(self):
        self._call_hook('before_trading')

    def call_handle_bar(self):
        self._call_hook('handle_bar')

    def call_after_trading(self):
        self._call_hook('after_trading')

    def call_broker_settle(self):
        self._call_hook('broker_settle')

    def call_on_end(self):
        self._call_hook('on_end')
