# qtrader/core/scheduler.py

import time as time_module
from datetime import datetime, timedelta
from typing import List
from ..core.context import Context
from ..core.time_manager import TimeManager
from ..core.lifecycle import LifecycleManager
from ..trading.matching_engine import MatchingEngine


class Scheduler:
    """
    事件调度器 (V4)
    
    支持暂停/恢复功能，性能优先设计。
    """

    def __init__(
        self,
        context: Context,
        time_manager: TimeManager,
        matching_engine: MatchingEngine,
        lifecycle_manager: LifecycleManager
    ):
        self.context = context
        self.time_manager = time_manager
        self.matching_engine = matching_engine
        self.lifecycle_manager = lifecycle_manager
        
        # 从新配置结构获取参数
        self.config = context.config
        self.engine_config = self.config.get('engine', {})
        
        
        # 生命周期配置
        self.lifecycle_config = self.config.get('lifecycle', {})
        
        # 服务器配置
        self.server_config = self.config.get('server', {})
        self._server_enabled = self.server_config.get('enable', False)
        self._update_interval = self.server_config.get('update_interval', 1.0)

        # 盘中统计更新配置
        self._enable_intraday_statistics = self.engine_config.get('enable_intraday_statistics', False)
        self._intraday_update_freq = self.engine_config.get('intraday_update_frequency', 5)
        self._intraday_last_record_minute = -1 # 用于跟踪上一分钟
        self._benchmark_start_of_day_price = None
        self._strategy_start_of_day_value = None

        # 构建回测时间点
        self._schedule_points = self._build_schedule_points()

    def _enter_pause_loop(self) -> bool:
        """
        私有辅助方法：进入暂停等待循环，并监听停止请求。
        返回 True 表示应继续运行, 返回 False 表示应终止。
        """
        while self.context.is_paused:
            # 在暂停期间，仍然要能响应停止指令
            if self.context.stop_requested:
                self.context.logger.info("在暂停期间收到停止指令，即将退出。")
                self.context.is_running = False
                self.context.was_interrupted = True
                return False
            time_module.sleep(0.1)
        
        # 如果循环正常退出（即恢复运行），再次检查 is_running 状态
        return self.context.is_running

    def _check_and_handle_requests(self) -> bool:
        """
        在安全点检查并处理暂停/停止请求。
        返回 True 表示应继续运行, 返回 False 表示应终止。
        """
        # 优先处理停止请求
        if self.context.stop_requested:
            self.context.logger.info("响应停止请求，即将终止回测循环。")
            self.context.is_running = False
            self.context.was_interrupted = True # 标记为用户中断
            return False

        # 再处理暂停请求
        if self.context.pause_requested:
            self.context.logger.info(f"响应暂停请求，将在 {self.context.current_dt} 暂停。")
            
            # 强制更新一次日内统计数据，确保数据完整性
            if self._enable_intraday_statistics:
                self._update_intraday_statistics(self.context.current_dt, force_update=True)
            
            # 保存状态
            if self.context.state_serializer:
                self.context.state_serializer.save(tag='pause')

            self.context.is_paused = True
            self.context.pause_requested = False # 清除请求

            # 进入暂停等待循环
            while self.context.is_paused:
                # 在暂停期间，仍然要能响应停止指令
                if self.context.stop_requested:
                    self.context.logger.info("在暂停期间收到停止指令，即将退出。")
                    self.context.is_running = False
                    self.context.was_interrupted = True
                    return False
                time_module.sleep(0.1)
            
            # 从暂停恢复后，再次检查 is_running 状态
            if not self.context.is_running:
                return False
        
        return True


    def run(self, skip_initialize: bool = False):
        """
        主运行循环
        
        Args:
            skip_initialize: 是否跳过initialize调用（用于分叉模式）
        """


        if not skip_initialize:
            self.lifecycle_manager.call_initialize()

        # 在进入主循环之前，处理“启动即暂停”的逻辑
        if self.context.start_paused:
            self.context.logger.info("回测以暂停状态启动。请在监控页面点击 '恢复' 继续。")
            self.context.is_paused = True
            self.context.start_paused = False  # 清除标志位

            # 触发一次UI更新，让前端知道当前是暂停状态
            self._maybe_update_server() 
            
            # 进入等待循环，但不执行任何保存操作
            if not self._enter_pause_loop():
                # 如果在初始暂停时就收到了停止指令，则直接返回
                return
        
        if self.context.mode == 'backtest':
            self._run_backtest(skip_initialize)
        else:
            self._run_simulation(skip_initialize)

    def _run_backtest(self, skip_initialize: bool = False):
        """回测模式运行循环"""

        # 1. 确定起始日期和时间
        start_date_str = self.context.start_date
        end_date_str = self.context.end_date

        # 只有在 skip_initialize 为 True (即恢复或分叉模式) 时，current_dt 才被视为恢复点
        resume_dt = self.context.current_dt if skip_initialize else None

        # 初始化策略
        if not skip_initialize:
            self.lifecycle_manager.call_initialize()
        
        if resume_dt:
            # 如果是恢复模式，起始日期从恢复点开始
            start_date_str = resume_dt.strftime('%Y-%m-%d')
            self.context.logger.info(f"从 {start_date_str} 的 {resume_dt.strftime('%H:%M:%S')} 之后继续回测")

        trading_days = self.time_manager.get_trading_days(start_date_str, end_date_str)
        
        if not trading_days:
            self.context.logger.warning("在指定日期范围内没有交易日，回测结束。")
            self.lifecycle_manager.call_on_end()
            return

        total_days = len(trading_days)
        self.context.logger.info(f"回测开始，共 {total_days} 个交易日")

        # 生命周期时间配置
        hooks = self.lifecycle_config.get('hooks', {})
        before_trading_time = hooks.get('before_trading', '09:15:00')
        after_trading_time = hooks.get('after_trading', '15:05:00')
        broker_settle_time = hooks.get('broker_settle', '15:30:00')

        # 2. 主循环
        for idx, date_str in enumerate(trading_days):
            # 检查运行状态
            if not self.context.is_running:
                self.context.logger.info("回测被手动停止")
                break

            self.context.logger.info(f"--- 交易日: {date_str} ({idx + 1}/{total_days}) ---")

            points_to_iterate = self._schedule_points
            is_resume_day = (resume_dt is not None and date_str == resume_dt.strftime('%Y-%m-%d'))

            if is_resume_day:
                self.context.logger.info("此为恢复日，跳过盘前准备流程。")
                # 恢复日也需要初始化日内统计的起点值
                if self.context.portfolio.history:
                    self._strategy_start_of_day_value = self.context.portfolio.history[-1]['total_value']
                if self.context.benchmark_manager.benchmark_history:
                    self._benchmark_start_of_day_price = self.context.benchmark_manager.benchmark_history[-1].get('close_price')
                self._intraday_last_record_minute = resume_dt.minute if resume_dt else -1

                try:
                    resume_time_str = resume_dt.strftime('%H:%M:%S')
                    points_to_iterate = [time_str for time_str in self._schedule_points if time_str > resume_time_str]
                    
                    if points_to_iterate:
                        self.context.logger.info(
                            f"根据新的调度计划，将从 bar: {points_to_iterate[0]} 开始执行。"
                        )
                    else:
                        self.context.logger.info(
                            f"恢复时间 ({resume_time_str}) 已晚于新调度计划中的所有时间点，直接进入盘后流程。"
                        )
                        points_to_iterate = []
                except ValueError:
                    self.context.logger.warning(f"无法在执行计划中找到恢复时间点 {resume_time_str}，将执行当天所有 bar。")
            else:
                # 2.1 盘前
                self._intraday_last_record_minute = -1
                self.context.symbol_info_cache.clear()
                self.context.intraday_equity_history.clear()
                self.context.intraday_benchmark_history.clear()
                self._benchmark_start_of_day_price = None
                self._strategy_start_of_day_value = None

                dt_before_trading = datetime.strptime(f"{date_str} {before_trading_time}", "%Y-%m-%d %H:%M:%S")
                self.context.current_dt = dt_before_trading
                self.lifecycle_manager.call_before_trading()

                if self.context.portfolio.history:
                    self._strategy_start_of_day_value = self.context.portfolio.history[-1]['total_value']
                if self.context.benchmark_manager.benchmark_history:
                    self._benchmark_start_of_day_price = self.context.benchmark_manager.benchmark_history[-1].get('close_price')
                
                self._maybe_update_server()
                if not self._check_and_handle_requests(): break

            # 2.2 盘中
            for time_str in points_to_iterate:
                dt_bar = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S")
                self.context.current_dt = dt_bar
                self.lifecycle_manager.call_handle_bar()
                self.matching_engine.match_orders(dt_bar)

                if self._enable_intraday_statistics:
                    self._update_intraday_statistics(dt_bar)
                self._maybe_update_server()

                if not self._check_and_handle_requests(): break
            
            if not self.context.is_running: break

            # 2.3 盘后
            dt_after_trading = datetime.strptime(f"{date_str} {after_trading_time}", "%Y-%m-%d %H:%M:%S")
            self.context.current_dt = dt_after_trading
            self.lifecycle_manager.call_after_trading()
            self._maybe_update_server()
            if not self._check_and_handle_requests(): break

            # 4. 结算
            dt_settle = datetime.strptime(f"{date_str} {broker_settle_time}", "%Y-%m-%d %H:%M:%S")
            self.context.current_dt = dt_settle
            self.matching_engine.settle()
            self.lifecycle_manager.call_broker_settle()
            self.context.benchmark_manager.update_daily()
            self._maybe_update_server()
            if not self._check_and_handle_requests(): break
            
            # 自动保存状态（可选）
            if self.context.config.get('workspace', {}).get('auto_save_state', False):
                auto_save_interval = self.context.config.get('workspace', {}).get('auto_save_interval', 10)
                auto_save_mode = self.context.config.get('workspace', {}).get('auto_save_mode', 'increment')
                if (idx + 1) % auto_save_interval == 0:  # 每10天保存一次
                    if self.context.state_serializer:
                        tag = 'auto_save' if auto_save_mode == 'overwrite' else f'auto_save_day_{idx+1}'
                        self.context.state_serializer.save(tag=tag)

        # 策略结束
        self.lifecycle_manager.call_on_end()
        self.context.logger.info("回测结束")

    def _maybe_update_server(self):
        """如果服务器启用，更新数据（性能优先：异步、有间隔）"""
        if self._server_enabled and self.context.visualization_server:
            # 异步更新，不阻塞
            self.context.visualization_server.trigger_update()

    def _run_simulation(self, skip_initialize: bool = False):
        """模拟盘模式（预留接口）"""
        self.context.logger.info("模拟盘模式尚未完全实现")
        if not skip_initialize:
            self.lifecycle_manager.call_initialize()
        # TODO: 实现模拟盘逻辑

    def _build_schedule_points(self) -> List[str]:
        """构建盘中时间点列表"""
        freq = self.context.frequency
        
        if freq == 'daily':
            hooks = self.lifecycle_config.get('hooks', {})
            handle_bar_time = hooks.get('handle_bar', '14:55:00')
            return [handle_bar_time] if isinstance(handle_bar_time, str) else handle_bar_time

        schedule = []
        sessions = self.lifecycle_config.get('trading_sessions', [])

        for start_str, end_str in sessions:
            current_dt = datetime.strptime(start_str, '%H:%M:%S')
            end_dt = datetime.strptime(end_str, '%H:%M:%S')
            tick_interval_seconds = self.engine_config.get('tick_interval_seconds', 3)
            delta = timedelta(minutes=1) if freq == 'minute' else timedelta(seconds=tick_interval_seconds)

            while current_dt <= end_dt:
                schedule.append(current_dt.strftime('%H:%M:%S'))
                current_dt += delta

        return sorted(list(set(schedule)))
    
    def _update_intraday_statistics(self, dt: datetime, force_update: bool = False):
        """按指定频率记录账户与基准的日内价值，并触发前端更新"""
        current_minute = dt.minute

        is_on_schedule = (dt.minute % self._intraday_update_freq == 0 and current_minute != self._intraday_last_record_minute)
        if not force_update and not is_on_schedule:
            return

        self._intraday_last_record_minute = current_minute
        
        # 1. 计算策略当前总市值
        pm = self.context.position_manager
        position_value = 0.0
        for pos in pm.get_all_positions():
            price_data = self.context.data_provider.get_current_price(pos.symbol, dt)
            current_price = price_data['current_price'] if price_data else pos.current_price
            pos.update_price(current_price)
            position_value += pos.market_value
        
        total_value = self.context.portfolio.cash + position_value
        
        self.context.intraday_equity_history.append({
            'time': dt.strftime('%H:%M:%S'),
            'total_value': total_value,
        })
        
        # 2. 计算基准当前价值 (与策略对齐)
        benchmark_symbol = self.context.benchmark_manager.benchmark_symbol
        # 使用 self._strategy_start_of_day_value
        if benchmark_symbol and self._benchmark_start_of_day_price and self._strategy_start_of_day_value:
            price_data = self.context.data_provider.get_current_price(benchmark_symbol, dt)
            if price_data and price_data.get('current_price'):
                current_benchmark_price = price_data['current_price']
                if self._benchmark_start_of_day_price > 0:
                    # [核心公式修改] 基准的显示价值 = 策略日初价值 * (基准当前价 / 基准日初价)
                    current_benchmark_value = self._strategy_start_of_day_value * (current_benchmark_price / self._benchmark_start_of_day_price)
                    self.context.intraday_benchmark_history.append({
                        'time': dt.strftime('%H:%M:%S'),
                        'value': current_benchmark_value,
                    })