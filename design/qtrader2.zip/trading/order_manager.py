# qtrader/trading/order_manager.py

from typing import Dict, List, Optional
from datetime import datetime
from ..trading.order import Order, OrderType, OrderSide, OrderStatus
from ..core.context import Context


class OrderManager:
    """订单管理器"""
    def __init__(self, context: Context):
        self.context = context
        self.orders: Dict[str, Order] = {}           # 当日所有订单
        self.filled_orders_history: List[Order] = [] # 历史成交订单

    def submit_order(
        self, symbol: str, amount: int, order_type: OrderType,
        price: Optional[float] = None, symbol_name: Optional[str] = None
    ) -> Optional[str]:
        if amount == 0:
            self.context.logger.warning("下单数量为0，订单被拒绝。")
            return None

        lot_size = int(self.context.config.get('order_lot_size', 1) or 1)
        lot_size = max(lot_size, 1)

        sign = 1 if amount > 0 else -1
        abs_amount = abs(amount)

        normalized_amount = (abs_amount // lot_size) * lot_size
        if normalized_amount == 0:
            self.context.logger.warning(
                f"下单数量 {abs_amount} 不满足最小交易单位 {lot_size}，订单被拒绝。"
            )
            return None

        if normalized_amount != abs_amount:
            self.context.logger.info(
                f"订单数量根据最小交易单位 {lot_size} 已从 {abs_amount} 调整为 {normalized_amount}。"
            )

        adjusted_amount = sign * normalized_amount

        side = OrderSide.BUY if adjusted_amount > 0 else OrderSide.SELL
        order = Order(
            symbol=symbol,
            amount=abs(adjusted_amount),
            side=side,
            order_type=order_type,
            limit_price=price,
            symbol_name=symbol_name
        )
        order.created_time = self.context.current_dt
        order.created_bar_time = self.context.current_dt
        self.orders[order.id] = order
        self.context.logger.info(
            f"提交订单: {order.id} | {side.value.upper()} {symbol} {order.amount} @ {'Market' if price is None else price}"
        )
        return order.id

    def cancel_order(self, order_id: str) -> bool:
        if order_id not in self.orders:
            self.context.logger.warning(f"撤单失败: 订单ID {order_id} 不存在。")
            return False

        order = self.orders[order_id]
        if order.cancel():
            self.context.logger.info(f"订单 {order_id} 已成功撤销。")
            return True
        else:
            self.context.logger.warning(f"撤单失败: 订单 {order_id} 状态为 {order.status.value}，无法撤销。")
            return False

    def get_open_orders(self) -> List[Order]:
        return [o for o in self.orders.values() if o.status == OrderStatus.OPEN]

    def get_filled_orders_today(self) -> List[Order]:
        return [o for o in self.orders.values() if o.status == OrderStatus.FILLED]

    def add_filled_order_to_history(self, order: Order):
        self.filled_orders_history.append(order)

    def get_all_orders_history(self) -> List[Order]:
        return self.filled_orders_history

    # 新增：实现 get_all_orders 方法
    def get_all_orders(self) -> List[Order]:
        """
        获取所有订单 (包括当日所有状态的订单和历史成交订单)。
        """
        all_orders = self.orders.copy()
        all_orders_dict = {}
        # 先加入当日订单，状态最新
        for order_id, order in all_orders.items():
            all_orders_dict[order_id] = order

        # 再加入历史成交订单，如果ID已存在则不覆盖
        for order in self.filled_orders_history:
            if order.id not in all_orders_dict:
                all_orders_dict[order.id] = order

        return list(all_orders_dict.values())

    def clear_today_orders(self):
        """日终结算时，清空当日非的订单记录（filled订单已加入到历史订单中）。"""
        self.orders.clear()

    def restore_orders(self, orders: List[Order]):
        self.filled_orders_history = [
            order for order in orders if order.status == OrderStatus.FILLED
        ]
        today_open_orders = [
            order for order in orders if order.status not in [OrderStatus.FILLED]
        ]
        for order in today_open_orders:
            self.orders[order.id] = order
