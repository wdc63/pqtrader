# 文件: qtrader/trading/matching_engine.py

from datetime import datetime
from typing import Dict, Optional, List, Tuple
from ..core.context import Context
from ..trading.order import Order, OrderStatus, OrderSide, OrderType
from ..trading.commission import CommissionCalculator
from ..trading.slippage import SlippageModel
from ..trading.position import PositionDirection

class MatchingEngine:
    """撮合引擎，支持多空交易。"""
    def __init__(self, context: Context, config: dict):
        self.context = context
        self.config = config
        self.commission_calc = CommissionCalculator(config.get('commission', {}))
        self.slippage_model = SlippageModel(config.get('slippage', {}))
        # [FIX] 从 account 配置节读取交易模式
        self.trading_mode = context.config.get('account', {}).get('trading_mode', 'long_only')

    def match_orders(self, dt: datetime):
        open_orders = self.context.order_manager.get_open_orders()
        immediate = [o for o in open_orders if o.is_immediate]
        historical = [o for o in open_orders if not o.is_immediate]

        for order in immediate:
            self._try_match_immediate(order, dt)

        for order in historical:
            self._try_match_historical(order, dt)

    # 辅助方法获取缓存的静态信息
    def _get_cached_symbol_info(self, symbol: str, dt: datetime) -> Optional[Dict]:
        date_str = dt.strftime('%Y-%m-%d')
        if symbol in self.context.symbol_info_cache:
            return self.context.symbol_info_cache[symbol]
        
        info = self.context.data_provider.get_symbol_info(symbol, date_str)
        if info:
            self.context.symbol_info_cache[symbol] = info
        return info

    def _try_match_immediate(self, order: Order, dt: datetime):
        price_data = self.context.data_provider.get_current_price(order.symbol, dt)
        symbol_info = self._get_cached_symbol_info(order.symbol, dt)
        
        if not price_data:
            order.mark_as_historical()
            return
            
        if not symbol_info:
            symbol_info = {            
                'symbol_name': order.symbol,
                'is_suspended': False,
            }
        
        snapshot = {**price_data, **symbol_info}

        if not self._pre_check(order, snapshot):
            return

        match_price = self._determine_immediate_match_price(order, snapshot)
        if match_price is None:
            order.mark_as_historical()
            return

        self._execute_match_flow(order, match_price, snapshot, dt)

    def _try_match_historical(self, order: Order, dt: datetime):
        price_data = self.context.data_provider.get_current_price(order.symbol, dt)
        symbol_info = self._get_cached_symbol_info(order.symbol, dt)

        if not price_data:
            order.mark_as_historical()
            return
            
        if not symbol_info:
            symbol_info = {            
                'symbol_name': order.symbol,
                'is_suspended': False,
            }
        
        snapshot = {**price_data, **symbol_info}
        if not snapshot:
            return
        
        if snapshot.get('is_suspended', False):
            return

        current_price = snapshot.get('current_price')
        can_match = False
        if order.side == OrderSide.BUY and current_price is not None:
            if order.order_type == OrderType.MARKET or current_price <= order.limit_price:
                can_match = True
        elif order.side == OrderSide.SELL and current_price is not None:
            if order.order_type == OrderType.MARKET or current_price >= order.limit_price:
                can_match = True

        if can_match:
            match_price = current_price if order.order_type == OrderType.MARKET else order.limit_price
            self._execute_match_flow(order, match_price, snapshot, dt)

    def _execute_match_flow(self, order: Order, match_price: float, snapshot: Dict, dt: datetime):
        # 1. 计算加滑点后的价格
        slippage = self.slippage_model.calculate(order, match_price)
        final_price = match_price + slippage if order.side == OrderSide.BUY else match_price - slippage

        # 检查1: 滑点后是否超出涨跌停
        if not self._check_limit_price_range(final_price, snapshot):
            reason = f"加滑点后价格 {final_price:.2f} 超出涨跌停范围"
            self.context.logger.warning(f"订单 {order.id} ({order.side.value} {order.amount} {order.symbol}) 被拒绝: {reason}")
            order.reject(reason)
            return
        
        # 2. 计算手续费
        commission = self.commission_calc.calculate(order, final_price)

        # 检查2: 资金/持仓是否充足
        can_trade, reason = self._check_sufficiency(order, final_price, commission)
        if not can_trade:
            self.context.logger.warning(f"订单 {order.id} ({order.side.value} {order.amount} {order.symbol}) 被拒绝: {reason}")
            order.reject(reason)
            return 
            
        # 3. 成交
        self._finalize_trade(order, final_price, commission, dt)

    def _determine_immediate_match_price(self, order: Order, snapshot: Dict) -> Optional[float]:
        price_ref = snapshot.get('current_price')
        ask1, bid1 = snapshot.get('ask1'), snapshot.get('bid1')

        if order.order_type == OrderType.MARKET:
            if order.side == OrderSide.BUY:
                return ask1 if ask1 else price_ref
            return bid1 if bid1 else price_ref

        if order.order_type == OrderType.LIMIT:
            if order.side == OrderSide.BUY:
                market_price = ask1 if ask1 else price_ref
                if market_price is None:
                    return None
                if order.limit_price >= market_price:
                    return market_price
            else:
                market_price = bid1 if bid1 else price_ref
                if market_price is None:
                    return None
                if order.limit_price <= market_price:
                    return market_price
        return None

    def _pre_check(self, order: Order, snapshot: Dict) -> bool:
        if order.symbol_name is None:
            order.symbol_name = snapshot.get('symbol_name')

        if snapshot.get('is_suspended', False):
            reason = f"标的 {order.symbol} 停牌"
            self.context.logger.warning(f"订单 {order.id} 被拒绝: {reason}")
            order.reject(reason)
            return False

        current, high, low = snapshot.get('current_price'), snapshot.get('high_limit'), snapshot.get('low_limit')
        if current is None:
            reason = f"缺少标的 {order.symbol} 的当前价格"
            self.context.logger.warning(f"订单 {order.id} 被拒绝: {reason}")
            order.reject(reason)
            return False

        if (order.side == OrderSide.BUY and high and abs(current - high) < 1e-6):
            reason = f"标的 {order.symbol} 当前价已涨停"
            self.context.logger.warning(f"订单 {order.id} 被拒绝: {reason}")
            order.reject(reason)
            return False
        
        if (order.side == OrderSide.SELL and low and abs(current - low) < 1e-6):
            reason = f"标的 {order.symbol} 当前价已跌停"
            self.context.logger.warning(f"订单 {order.id} 被拒绝: {reason}")
            order.reject(reason)
            return False
            
        return True

    def _check_limit_price_range(self, price: float, snapshot: Dict) -> bool:
        high, low = snapshot.get('high_limit'), snapshot.get('low_limit')
        if high is not None and low is not None:
            # 增加一个极小的容差范围，避免浮点数精度问题
            return (low - 1e-6) <= price <= (high + 1e-6)
        return True

    def _check_sufficiency(self, order: Order, price: float, commission: float) -> Tuple[bool, str]:
        portfolio = self.context.portfolio
        pm = self.context.position_manager
        rule = self.context.config.get('account', {}).get('trading_rule', 'T+1')

        if order.side == OrderSide.BUY:
            cash_needed = price * order.amount + commission
            if portfolio.cash >= cash_needed:
                return True, ""
            
            # 检查是否为平空仓 (平仓总是允许的，不受资金限制)
            short_pos = pm.get_position(order.symbol, PositionDirection.SHORT)
            if short_pos and short_pos.total_amount > 0:
                return True, ""

            return False, f"可用资金不足 (需要: {cash_needed:,.2f}, 可用: {portfolio.cash:,.2f})"

        # SELL
        long_pos = pm.get_position(order.symbol, PositionDirection.LONG)
        
        # 场景1: 有多头持仓，检查是否足够卖出
        if long_pos and long_pos.total_amount > 0:
            available = long_pos.available_amount if rule == 'T+1' else long_pos.total_amount
            if available >= order.amount:
                return True, ""
            else:
                reason = (f"T+1规则限制, 可用持仓不足 "
                          f"(总持仓: {long_pos.total_amount}, 可用: {available}, 欲卖: {order.amount})")
                return False, reason
        
        # 场景2: 没有多头持仓，检查是否允许开空仓
        if self.trading_mode == 'long_short':
            return True, ""

        # 场景3: 既无足够多头持仓，也不允许开空
        return False, "持仓不足"

    def _finalize_trade(self, order: Order, price: float, commission: float, dt: datetime):
        order.fill(price, commission, dt)
        self.context.order_manager.add_filled_order_to_history(order)

        pm = self.context.position_manager
        portfolio = self.context.portfolio

        gross_value = price * order.amount
        realized_pnl = pm.process_trade(order, price, dt, self.trading_mode)

        if order.side == OrderSide.BUY:
            # 如果是平空仓，已实现盈亏已经计算，这里只需处理保证金/现金变化
            # 在简化模型中，我们假设现金流是直接的
            portfolio.cash -= gross_value + commission
        else: # SELL
            portfolio.cash += gross_value - commission

        # 根据是否产生实际盈亏来决定日志内容
        if realized_pnl != 0:
            self.context.logger.info(
                f"✅ 成交[{order.side.value.upper()}] {order.symbol} 数量:{order.amount} "
                f"价格:{price:.2f} | 实现盈亏: {realized_pnl - commission:.2f}"
            )
        else:
            self.context.logger.info(
                f"✅ 成交[{order.side.value.upper()}] {order.symbol} 数量:{order.amount} 价格:{price:.2f}"
            )

    def settle(self):
        """每日结算"""
        self.context.logger.info("开始每日结算...")
        # 1. 取消所有当天未成交的、非历史的订单
        for order in self.context.order_manager.get_open_orders():
            if not order.is_immediate: # 通常日内循环后剩下的都是历史挂单
                order.expire()

        self.context.order_manager.clear_today_orders()
        
        # 2. 结算所有持仓
        pm = self.context.position_manager
        total_pos_value = 0.0
        date_str = self.context.current_dt.strftime('%Y-%m-%d')
        snapshot_entries: List[Dict] = []

        for pos in pm.get_all_positions():
            price_data = self.context.data_provider.get_current_price(pos.symbol, self.context.current_dt)
            if price_data and 'current_price' in price_data and price_data['current_price'] is not None:
                close_price = price_data['current_price']
                settle_entry = pos.settle_day(close_price, date_str)
                if settle_entry:
                    snapshot_entries.append(settle_entry)
                    # 多头市值增加总资产，空头市值减少总资产（因为空头是负债）
                    total_pos_value += settle_entry['market_value'] if pos.direction == PositionDirection.LONG else -settle_entry['market_value']
            else:
                self.context.logger.warning(f"无法获取 {pos.symbol} 在 {date_str} 的收盘价用于结算。")

            # T+1 规则结算：将今天开的仓位变为明天可用的仓位
            if self.context.config.get('account', {}).get('trading_rule', 'T+1') == 'T+1':
                pos.settle_t1()

        pm.daily_snapshots = [s for s in pm.daily_snapshots if s.get('date') != date_str]
        pm.record_daily_snapshot(date_str, snapshot_entries)
        self.context.portfolio.record_history(self.context.current_dt, total_pos_value)
        self.context.logger.info(f"结算完成, 总资产: {self.context.portfolio.total_value:,.2f}")