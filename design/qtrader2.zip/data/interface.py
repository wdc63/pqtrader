# qtrader/data/interface.py

from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from datetime import datetime

class AbstractDataProvider(ABC):
    """
    抽象数据提供者 (AbstractDataProvider)

    这是框架与数据层之间的接口合约。用户必须实现这个抽象基类。
    """
    
    @abstractmethod
    def get_trading_calendar(self, start: str, end: str) -> List[str]:
        """
        获取交易日历。返回 [ 'YYYY-MM-DD', ... ] 格式的列表。
        """
        pass
    
    @abstractmethod
    def get_current_price(self, symbol: str, dt: datetime) -> Optional[Dict]:
        """
        [新] 获取当前时刻的价格快照。这是高频调用的核心接口。
        返回格式:
        {
            'current_price': float (必须),
            'ask1': float (可选),
            'bid1': float (可选),
            'high_limit': float (可选),
            'low_limit': float (可选),
        }
        """
        pass
    
    @abstractmethod
    def get_symbol_info(self, symbol: str, date: str) -> Optional[Dict]:
        """
        [新] 获取指定日期的标的静态信息。这是低频调用的接口。
        返回格式:
        {
            'symbol_name': str,
            'is_suspended': bool,
        }
        """
        pass