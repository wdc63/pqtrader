# qtrader/runner/backtest_runner.py

from qtrader.core.engine import Engine
from typing import Optional

class BacktestRunner:
    """
    回测启动器 (V5) - 程序化接口

    提供以函数调用方式启动全新、恢复或分叉回测的方法。
    """

    @staticmethod
    def run_new(
        config_path: str, 
        strategy_path: str, 
        data_provider_path: str,
        start_paused: bool = False  
    ):
        """
        启动一个全新的回测。

        Args:
            config_path (str): 配置文件路径。
            strategy_path (str): 策略文件路径。
            data_provider_path (str): 数据提供者文件路径。
            start_paused (bool): 如果为 True，回测将在启动后立即暂停，可选，默认为 False。
        """
        print("=" * 60)
        print("QTrader - 启动全新回测 (程序化调用)")
        print("=" * 60)
        print(f"配置文件: {config_path}")
        print(f"策略文件: {strategy_path}")
        print(f"数据提供者: {data_provider_path}")
        if start_paused:
            print("启动模式: 立即暂停")
        print("=" * 60)
        try:
            engine = Engine(config_path)
            # 将参数传递给 engine.run
            engine.run(strategy_path, data_provider_path, start_paused=start_paused)
        except Exception as e:
            print(f"\n运行失败: {e}")
            import traceback
            traceback.print_exc()

    @staticmethod
    def run_resume(
        state_file: str, 
        config_path: Optional[str] = None, 
        data_provider: Optional[str] = None, 
        start_paused: bool = False
    ):
        """
        从状态文件恢复一个中断的回测。

        Args:
            state_file (str): 状态文件 (.pkl) 的路径。
            config_path (Optional[str]): （可选）新的配置文件路径，用于覆盖状态中的配置。
            data_provider (Optional[str]): （可选）新的数据提供者路径。
            start_paused (bool): （可选）如果为 True，回测将在启动后立即暂停，默认为 False。
        """
        print("=" * 60)
        print("QTrader - 恢复中断的回测 (程序化调用)")
        print("=" * 60)
        print(f"状态文件: {state_file}")
        if config_path:
            print(f"覆盖配置文件: {config_path}")
        if data_provider:
            print(f"覆盖数据提供者: {data_provider}")
        if start_paused:
            print("启动模式: 立即暂停")
        print("=" * 60)
        try:
            engine = Engine.load_from_state(state_file, config_path)
            engine.resume(data_provider, start_paused=start_paused)
        except Exception as e:
            print(f"\n运行失败: {e}")
            import traceback
            traceback.print_exc()

    @staticmethod
    def run_fork(
        state_file: str, 
        strategy_path: str, 
        config_path: Optional[str] = None, 
        data_provider: Optional[str] = None, 
        no_reinit: bool = False,
        start_paused: bool = False
    ):
        """
        从一个历史状态文件分叉出一个新的回测，即允许使用新的策略对暂停回测文件进行回测（可重新初始化，重新开始暂停当天，不保留盘中数据）。

        Args:
            state_file (str): 用于分叉的状态文件 (.pkl) 的路径。
            strategy_path (str): 新的策略文件路径。
            config_path (Optional[str]): （可选）新的配置文件路径。
            data_provider (Optional[str]): （可选）新的数据提供者路径。
            no_reinit (bool): （可选）如果为 True，则不重新初始化策略，默认为 False。
            start_paused (bool): （可选）如果为 True，回测将在启动后立即暂停，默认为 False。
        """
        reinitialize = not no_reinit
        print("=" * 60)
        print("QTrader - 从快照分叉回测 (程序化调用)")
        print("=" * 60)
        print(f"状态文件: {state_file}")
        print(f"新策略文件: {strategy_path}")
        if config_path:
            print(f"覆盖配置文件: {config_path}")
        if data_provider:
            print(f"新数据提供者: {data_provider}")
        print(f"重新初始化策略: {'是' if reinitialize else '否 (高级模式)'}")
        if start_paused:
            print("启动模式: 立即暂停")
        print("=" * 60)
        
        try:
            engine = Engine.load_from_state(state_file, config_path)
            engine.run_from_snapshot(
                strategy=strategy_path,
                data_provider=data_provider,
                reinitialize=reinitialize,
                start_paused=start_paused
            )
        except Exception as e:
            print(f"\n运行失败: {e}")
            import traceback
            traceback.print_exc()