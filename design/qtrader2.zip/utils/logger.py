# qtrader/utils/logger.py

import logging
import sys
from typing import Dict, Any, Optional
from datetime import datetime

# 创建一个自定义的 Filter，用于注入上下文信息
class ContextFilter(logging.Filter):
    """
    一个将上下文信息（如模拟时间）注入到日志记录中的过滤器。
    """
    def __init__(self, context, name=''):
        super().__init__(name)
        self.context = context

    def filter(self, record):
        """
        为日志记录动态附加 sim_time 属性。
        这个方法会在每条日志被处理前调用。
        """
        # 从 context 中获取当前的模拟时间
        sim_dt = getattr(self.context, 'current_dt', None)
        
        if sim_dt:
            # 如果存在模拟时间，就格式化并附加到记录上
            record.sim_time = sim_dt.strftime('%Y-%m-%d %H:%M:%S')
        else:
            # 如果不存在（例如回测开始前），使用占位符以保持格式对齐
            record.sim_time = ' ' * 19  # 19个空格，与 'YYYY-MM-DD HH:MM:SS' 等宽
        return True


class InMemoryLogHandler(logging.Handler):
    """
    将日志写入 Context.log_buffer，便于实时监控展示。
    """
    def __init__(self, context, capacity: int):
        super().__init__()
        self.context = context
        self.capacity = capacity

    def emit(self, record: logging.LogRecord):
        """
        [修改] 简化emit方法，直接使用Filter附加的属性来构造结构化日志。
        """
        if self.context is None:
            return
        
        # 直接从日志记录(record)中获取所需信息
        # record.sim_time 是由我们上面的 ContextFilter 添加的
        entry = {
            "exec_time": datetime.fromtimestamp(record.created).isoformat(timespec='seconds'),
            "sim_time": getattr(record, 'sim_time', ''), # 从Filter附加的属性获取
            "level": record.levelname,
            "message": record.getMessage() # 只获取最原始、干净的日志消息
        }
        
        self.context.log_buffer.append(entry)
        overflow = len(self.context.log_buffer) - self.capacity
        if overflow > 0:
            del self.context.log_buffer[:overflow]


def setup_logger(config: Dict[str, Any], context=None) -> logging.Logger:
    """
    [修改] 更新日志格式化程序并应用新的过滤器，实现双时间戳日志。
    """
    logger = logging.getLogger("qtrader")
    logger.propagate = False

    if logger.hasHandlers():
        logger.handlers.clear()

    level = getattr(logging, config.get('level', 'INFO').upper(), logging.INFO)
    logger.setLevel(level)

    # 定义包含双时间戳的日志格式
    # %(asctime)s 是执行时间
    # %(sim_time)s 是通过Filter注入的模拟时间
    log_format = '[Exec: %(asctime)s] [Sim: %(sim_time)s] - %(levelname)s - %(message)s'
    formatter = logging.Formatter(log_format, datefmt='%Y-%m-%d %H:%M:%S')
    
    # 如果有context，则创建并添加过滤器到logger实例
    # 这一步是关键，它确保所有附加到此logger的handler都能处理带有sim_time的记录
    if context:
        context_filter = ContextFilter(context)
        logger.addFilter(context_filter)

    # 为控制台输出应用新格式
    if config.get('console_output', True):
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(level)
        ch.setFormatter(formatter)
        logger.addHandler(ch)

    # 为文件输出应用新格式
    log_file = config.get('file')
    if log_file:
        try:
            fh = logging.FileHandler(log_file, mode='a', encoding='utf-8')
            fh.setLevel(level)
            fh.setFormatter(formatter)
            logger.addHandler(fh)
        except Exception as e:
            logger.error(f"无法创建日志文件 {log_file}: {e}")

    # 为内存（网页）handler设置
    buffer_size = config.get('buffer_size', 1000)
    if context is not None:
        context.log_buffer_limit = buffer_size
        memory_handler = InMemoryLogHandler(context, buffer_size)
        memory_handler.setLevel(level)
        # InMemoryLogHandler 直接处理 record 对象，不需要自己的 formatter
        logger.addHandler(memory_handler)

    return logger